import assert from "node:assert/strict";
import { webcrypto } from "node:crypto";

const values = new Map();
globalThis.localStorage = {
  getItem: (key) => values.has(key) ? values.get(key) : null,
  setItem: (key, value) => values.set(key, String(value)),
  removeItem: (key) => values.delete(key)
};
Object.defineProperty(globalThis, "crypto", { value: webcrypto });
globalThis.window = {
  crypto: webcrypto,
  TextEncoder,
  setTimeout,
  clearTimeout
};

await import(`../auth.js?test=${Date.now()}`);
const auth = window.DesktopcraftAuth;
const created = await auth.signUp({ name: "Local Builder", username: "local_builder", password: "desktop-pass" });
assert.equal(created.username, "local_builder");
assert.equal(auth.currentUser().name, "Local Builder");

auth.signOut();
assert.equal(auth.currentUser(), null);
const signedIn = await auth.signIn({ username: "LOCAL_BUILDER", password: "desktop-pass" });
assert.equal(signedIn.username, "local_builder");

assert.equal(auth.recordProgress({ "java-swing": { completed: 2, total: 500 } }), true);
const leaderboard = await auth.leaderboardEntries();
assert.equal(leaderboard.length, 1);
assert.equal(leaderboard[0].courses["java-swing"].completed, 2);

console.log("Verified browser-storage account fallback and local leaderboard.");
