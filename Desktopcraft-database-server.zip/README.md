# Desktopcraft

An interactive, dependency-free desktop application tutor with **2,500 guided lessons across five courses**. Lessons use short, plain-language teaching text while keeping real API names. Every lesson includes an editable example, browser-based UI simulation, an automatically checked coding challenge, a guided 20-question quiz with answer explanations, and a complete reference covering properties, functions, events, execution flow, vocabulary, and every starter-code line. The site also provides curriculum search, independent course progress, and an XP leaderboard.

The website also includes a five-language quick-start tutorial hub with searchable topics, editable runnable examples, simulator output, code copy/reset controls, and locally saved completion.

The Builder Forum provides login-aware discussions with categories, search, sorting, replies, likes, optional code samples, and profanity-safe posting. Forum drafts currently stay in the browser.

Desktopcraft includes account creation and sign-in with a Desktopcraft username and a separate Desktopcraft-only password—never an email password. When the site runs with its included SQLite server, accounts, secure sessions, lesson completions, quiz attempts, XP, and leaderboard standings are stored in the database. Passwords are salted and hashed before storage. Creating an account still produces a password-free JSON memory file that can refill the identity later.

A static upload also remains supported. Without the API server, the website automatically falls back to browser storage, keeping up to 100 account records in primary storage and sending later records to IndexedDB overflow storage.

The website and Swing app both include a lesson studio. Creators supply a lesson name, starter code, answer, and expected output; published lessons join the selected local course. A clearly disclosed profanity rule rejects a violating submission, erases its draft and all locally created lessons, and permanently disables creation for that browser/app profile.

App Maker is also available on the website and in the Swing edition. It turns a small visual blueprint into starter source for Java Swing, Python Tkinter, C# WinForms, C++ Qt Widgets, or JavaScript Electron, with an interactive preview plus copy/download or save-source actions.

## Run locally

Create and verify a production build:

```bash
npm run publish:check
```

Preview the resulting site:

```bash
npm run preview
```

Then visit `http://localhost:4173`. The deployable site is written to `dist/` and contains only public website files, assets, and the downloadable desktop packages.

## Run with the database

Initialize SQLite, build the site, and start the database-backed server:

```bash
npm run db:init
npm run build
npm start
```

Then visit `http://localhost:8000`. The default database file is `database/desktopcraft.db`. Set `DESKTOPCRAFT_DB_PATH` to choose another location. The server uses same-origin, HTTP-only session cookies and does not expose password hashes to the browser.

Run the database integration test with:

```bash
npm run test:database
```

## Publish

For shared accounts and rankings, deploy the included `Dockerfile` and mount persistent storage at `/data`. The container serves the site and API on port `8000`, with SQLite stored at `/data/desktopcraft.db`.

Netlify and Vercel configuration files are also included for a static-only edition. Import the repository into either service and its build system will run `npm run build` and publish `dist/`. On static hosting, Desktopcraft uses its browser-storage fallback, so accounts and rankings are limited to that browser.

## Courses

- Java Swing — 500 lessons
- Python Tkinter — 500 lessons
- C# Windows Forms — 500 lessons
- C++ Qt Widgets — 500 lessons
- JavaScript Electron — 500 lessons

## Simulator coverage

The local simulator reads code in the editor and recreates a practical desktop UI subset in the browser:

- Java Swing frames, components, layouts, models, and common listeners
- Tkinter windows, ttk controls, commands, and geometry-managed interfaces
- WinForms controls and Click events, Qt widgets and signals, and Electron DOM controls
- Labels, buttons, text controls, choices, lists, tables, trees, and progress feedback
- Console feedback, lightweight syntax checks, and editable/resettable lesson code

This is a safe teaching interpreter rather than a language runtime, so arbitrary libraries and operating-system APIs are intentionally not executed. Lesson snippets can be copied into the appropriate local development environment for full execution.

## Curriculum

Use the course picker in the sidebar to switch tracks. Each course remembers its own lesson, progress, and edited code. Press `/` anywhere outside the editor to search the current curriculum.

## Leaderboard

Open `leaderboard.html` or use the trophy link in the tutor. Completed lessons award 100 XP. With the SQLite server, rankings are shared by all registered learners. The rankings contain only real Desktopcraft accounts and recorded course completions—there are no sample builders or invented scores.

## Website icon and desktop download

The shared Desktopcraft icon is used as the website favicon and brand mark. The Java Swing edition draws the same mark for its application windows and login dialogs. Download the runnable JAR or source ZIP from the course sidebar.
