# Desktopcraft database

Desktopcraft uses SQLite through Python's standard library. No database package needs to be installed.

The schema stores users, salted password hashes, sessions, per-course progress, exact lesson completions, 20-question quiz attempts, custom-lesson records, and forum records. The current API connects accounts, sessions, course progress, quiz attempts, XP, and the shared leaderboard.

From the project root:

```bash
npm run db:init
npm run build
npm start
```

Useful environment variables:

- `DESKTOPCRAFT_DB_PATH` — SQLite file path; defaults to `database/desktopcraft.db`
- `DESKTOPCRAFT_SITE_ROOT` — built website directory; defaults to `dist`
- `HOST` and `PORT` — listening address and port
- `DESKTOPCRAFT_SECURE_COOKIES=true` — require HTTPS for the session cookie in production

Back up the database by stopping the server and copying the `.db` file. Docker deployments should mount persistent storage at `/data`.
