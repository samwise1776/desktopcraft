import http.client
import json
import tempfile
import threading
import unittest
from pathlib import Path

from database import server


class DatabaseApiTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        server.DB_PATH = Path(self.temp.name) / "desktopcraft-test.db"
        server.initialize_database()
        self.httpd = server.ThreadingHTTPServer(("127.0.0.1", 0), server.DesktopcraftHandler)
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self.connection = http.client.HTTPConnection("127.0.0.1", self.httpd.server_port, timeout=5)

    def tearDown(self):
        self.connection.close()
        self.httpd.shutdown()
        self.httpd.server_close()
        self.thread.join(timeout=2)
        self.temp.cleanup()

    def request(self, method, path, payload=None, cookie=None):
        headers = {"Content-Type": "application/json"}
        if cookie: headers["Cookie"] = cookie
        body = json.dumps(payload).encode() if payload is not None else None
        self.connection.request(method, path, body=body, headers=headers)
        response = self.connection.getresponse()
        data = json.loads(response.read() or b"{}")
        return response, data

    def test_account_progress_and_leaderboard(self):
        response, payload = self.request("POST", "/api/auth/register", {"name": "Ada Builder", "username": "ada_builder", "password": "desktop-pass"})
        self.assertEqual(response.status, 201)
        self.assertEqual(payload["user"]["username"], "ada_builder")
        cookie = response.getheader("Set-Cookie").split(";", 1)[0]

        response, payload = self.request("PUT", "/api/progress", {"courseId": "java-swing", "activeLesson": 3, "completed": [0, 1, 3]}, cookie)
        self.assertEqual(response.status, 200)
        self.assertEqual(payload["xp"], 300)

        response, payload = self.request("GET", "/api/progress", cookie=cookie)
        self.assertEqual(response.status, 200)
        self.assertEqual(payload["courses"][0]["completed"], [0, 1, 3])

        response, payload = self.request("POST", "/api/quiz-attempts", {"courseId": "java-swing", "lessonIndex": 3, "score": 17}, cookie)
        self.assertEqual(response.status, 201)
        self.assertTrue(payload["ok"])

        response, payload = self.request("GET", "/api/leaderboard")
        self.assertEqual(response.status, 200)
        self.assertEqual(payload["entries"][0]["courses"]["java-swing"]["xp"], 300)

        response, payload = self.request("POST", "/api/auth/login", {"username": "ada_builder", "password": "desktop-pass"})
        self.assertEqual(response.status, 200)
        self.assertEqual(payload["user"]["name"], "Ada Builder")

        response, payload = self.request("POST", "/api/auth/logout", {}, cookie)
        self.assertEqual(response.status, 200)
        self.assertEqual(response.getheader("Set-Cookie").split(";", 1)[0], "desktopcraft_session=")

        response, payload = self.request("GET", "/api/progress", cookie=cookie)
        self.assertEqual(response.status, 401)
        self.assertIn("Sign in", payload["error"])


if __name__ == "__main__":
    unittest.main()
