#!/usr/bin/env python3
"""Desktopcraft static site and SQLite API server."""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import time
from http import cookies
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SITE_ROOT = Path(os.environ.get("DESKTOPCRAFT_SITE_ROOT", PROJECT_ROOT / "dist")).resolve()
DB_PATH = Path(os.environ.get("DESKTOPCRAFT_DB_PATH", PROJECT_ROOT / "database" / "desktopcraft.db")).resolve()
SESSION_COOKIE = "desktopcraft_session"
SESSION_SECONDS = 60 * 60 * 24 * 30
MAX_BODY_BYTES = 1_000_000
COURSE_IDS = {"java-swing", "python-tkinter", "csharp-winforms", "cpp-qt", "javascript-electron"}
USERNAME_PATTERN = re.compile(r"^[a-z0-9_.-]{3,24}$")


def now() -> int:
    return int(time.time())


def connect(database_path: Path | None = None) -> sqlite3.Connection:
    connection = sqlite3.connect(database_path or DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 5000")
    return connection


def initialize_database(database_path: Path | None = None) -> None:
    path = database_path or DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    schema = (Path(__file__).parent / "schema.sql").read_text(encoding="utf-8")
    with connect(path) as database:
        database.execute("PRAGMA journal_mode = WAL")
        database.executescript(schema)


def make_password(password: str) -> tuple[str, str]:
    salt = os.urandom(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return base64.urlsafe_b64encode(digest).decode(), base64.urlsafe_b64encode(salt).decode()


def verify_password(password: str, encoded_digest: str, encoded_salt: str) -> bool:
    try:
        salt = base64.urlsafe_b64decode(encoded_salt.encode())
        expected = base64.urlsafe_b64decode(encoded_digest.encode())
        actual = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32)
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


class DesktopcraftHandler(SimpleHTTPRequestHandler):
    server_version = "Desktopcraft/1.0"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, directory=str(SITE_ROOT), **kwargs)

    def end_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        super().end_headers()

    def log_message(self, message: str, *args: Any) -> None:
        print(f"[{self.log_date_time_string()}] {message % args}")

    def send_json(self, status: int, payload: dict[str, Any], extra_headers: dict[str, str] | None = None) -> None:
        data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for key, value in (extra_headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(data)

    def read_json(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exception:
            raise ValueError("Invalid request size.") from exception
        if length <= 0 or length > MAX_BODY_BYTES:
            raise ValueError("Request body is empty or too large.")
        try:
            payload = json.loads(self.rfile.read(length))
        except (json.JSONDecodeError, UnicodeDecodeError) as exception:
            raise ValueError("Request body must be valid JSON.") from exception
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object.")
        return payload

    def session_token(self) -> str:
        jar = cookies.SimpleCookie(self.headers.get("Cookie", ""))
        return jar.get(SESSION_COOKIE).value if jar.get(SESSION_COOKIE) else ""

    def current_user(self) -> sqlite3.Row | None:
        token = self.session_token()
        if not token:
            return None
        timestamp = now()
        with connect() as database:
            database.execute("DELETE FROM sessions WHERE expires_at <= ?", (timestamp,))
            return database.execute(
                """SELECT users.id, users.username, users.display_name, users.created_at
                   FROM sessions JOIN users ON users.id = sessions.user_id
                   WHERE sessions.token_hash = ? AND sessions.expires_at > ?""",
                (token_hash(token), timestamp),
            ).fetchone()

    def require_user(self) -> sqlite3.Row | None:
        user = self.current_user()
        if not user:
            self.send_json(401, {"error": "Sign in to continue."})
        return user

    def create_session(self, user_id: int) -> tuple[str, int]:
        token = secrets.token_urlsafe(32)
        expires_at = now() + SESSION_SECONDS
        with connect() as database:
            database.execute(
                "INSERT INTO sessions(token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)",
                (token_hash(token), user_id, now(), expires_at),
            )
        return token, expires_at

    def session_cookie(self, token: str, max_age: int = SESSION_SECONDS) -> str:
        secure = "; Secure" if os.environ.get("DESKTOPCRAFT_SECURE_COOKIES", "").lower() in {"1", "true", "yes"} else ""
        return f"{SESSION_COOKIE}={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={max_age}{secure}"

    @staticmethod
    def public_user(user: sqlite3.Row) -> dict[str, Any]:
        return {"id": user["id"], "username": user["username"], "name": user["display_name"], "createdAt": user["created_at"] * 1000, "storageTier": "database"}

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/health":
            with connect() as database:
                user_count = database.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            self.send_json(200, {"ok": True, "database": "sqlite", "users": user_count})
        elif path == "/api/auth/session":
            user = self.current_user()
            self.send_json(200, {"user": self.public_user(user) if user else None})
        elif path == "/api/progress":
            user = self.require_user()
            if user:
                self.get_progress(user)
        elif path == "/api/leaderboard":
            self.get_leaderboard()
        elif path.startswith("/api/"):
            self.send_json(404, {"error": "API route not found."})
        else:
            if path == "/": self.path = "/index.html"
            super().do_GET()

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            if path == "/api/auth/register": self.register()
            elif path == "/api/auth/login": self.login()
            elif path == "/api/auth/logout": self.logout()
            elif path == "/api/quiz-attempts": self.save_quiz_attempt()
            else: self.send_json(404, {"error": "API route not found."})
        except (ValueError, TypeError) as exception:
            self.send_json(400, {"error": str(exception)})

    def do_PUT(self) -> None:
        try:
            if urlparse(self.path).path == "/api/progress":
                user = self.require_user()
                if user: self.save_progress(user)
            else:
                self.send_json(404, {"error": "API route not found."})
        except (ValueError, TypeError) as exception:
            self.send_json(400, {"error": str(exception)})

    def register(self) -> None:
        payload = self.read_json()
        name = str(payload.get("name", "")).strip()
        username = str(payload.get("username", "")).strip().lower()
        password = str(payload.get("password", ""))
        if len(name) < 2 or len(name) > 80: raise ValueError("Enter a name with 2–80 characters.")
        if not USERNAME_PATTERN.fullmatch(username): raise ValueError("Use 3–24 letters, numbers, dots, dashes, or underscores for your username.")
        if len(password) < 8 or len(password) > 200: raise ValueError("Use 8–200 characters for your Desktopcraft password.")
        digest, salt = make_password(password)
        timestamp = now()
        try:
            with connect() as database:
                cursor = database.execute(
                    "INSERT INTO users(username, display_name, password_hash, password_salt, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (username, name, digest, salt, timestamp, timestamp),
                )
                user_id = cursor.lastrowid
                user = database.execute("SELECT id, username, display_name, created_at FROM users WHERE id = ?", (user_id,)).fetchone()
        except sqlite3.IntegrityError:
            self.send_json(409, {"error": "That Desktopcraft username is already taken."})
            return
        token, _ = self.create_session(user_id)
        self.send_json(201, {"user": self.public_user(user)}, {"Set-Cookie": self.session_cookie(token)})

    def login(self) -> None:
        payload = self.read_json()
        username = str(payload.get("username", "")).strip().lower()
        password = str(payload.get("password", ""))
        with connect() as database:
            user = database.execute(
                "SELECT id, username, display_name, password_hash, password_salt, created_at FROM users WHERE username = ?",
                (username,),
            ).fetchone()
        if not user or not verify_password(password, user["password_hash"], user["password_salt"]):
            self.send_json(401, {"error": "Desktopcraft username or password is incorrect."})
            return
        token, _ = self.create_session(user["id"])
        self.send_json(200, {"user": self.public_user(user)}, {"Set-Cookie": self.session_cookie(token)})

    def logout(self) -> None:
        token = self.session_token()
        if token:
            with connect() as database:
                database.execute("DELETE FROM sessions WHERE token_hash = ?", (token_hash(token),))
        self.send_json(200, {"ok": True}, {"Set-Cookie": self.session_cookie("", 0)})

    def get_progress(self, user: sqlite3.Row) -> None:
        with connect() as database:
            rows = database.execute(
                "SELECT course_id, active_lesson, completed_count, total_lessons, xp, updated_at FROM course_progress WHERE user_id = ?",
                (user["id"],),
            ).fetchall()
            completions = database.execute(
                "SELECT course_id, lesson_index FROM lesson_completions WHERE user_id = ? ORDER BY lesson_index",
                (user["id"],),
            ).fetchall()
        completed_by_course: dict[str, list[int]] = {course_id: [] for course_id in COURSE_IDS}
        for completion in completions: completed_by_course.setdefault(completion["course_id"], []).append(completion["lesson_index"])
        courses = [{
            "courseId": row["course_id"], "activeLesson": row["active_lesson"], "completed": completed_by_course.get(row["course_id"], []),
            "completedCount": row["completed_count"], "total": row["total_lessons"], "xp": row["xp"], "updatedAt": row["updated_at"] * 1000,
        } for row in rows]
        self.send_json(200, {"courses": courses})

    def save_progress(self, user: sqlite3.Row) -> None:
        payload = self.read_json()
        course_id = str(payload.get("courseId", ""))
        if course_id not in COURSE_IDS: raise ValueError("Unknown course.")
        completed_input = payload.get("completed", [])
        if not isinstance(completed_input, list): raise ValueError("Completed lessons must be an array.")
        completed = sorted({int(index) for index in completed_input if isinstance(index, int) and 0 <= index < 500})
        active_lesson = max(0, min(499, int(payload.get("activeLesson", 0))))
        timestamp = now()
        with connect() as database:
            database.execute("BEGIN IMMEDIATE")
            database.execute("DELETE FROM lesson_completions WHERE user_id = ? AND course_id = ?", (user["id"], course_id))
            database.executemany(
                "INSERT INTO lesson_completions(user_id, course_id, lesson_index, completed_at) VALUES (?, ?, ?, ?)",
                [(user["id"], course_id, index, timestamp) for index in completed],
            )
            database.execute(
                """INSERT INTO course_progress(user_id, course_id, active_lesson, completed_count, total_lessons, xp, updated_at)
                   VALUES (?, ?, ?, ?, 500, ?, ?)
                   ON CONFLICT(user_id, course_id) DO UPDATE SET active_lesson=excluded.active_lesson,
                   completed_count=excluded.completed_count, total_lessons=500, xp=excluded.xp, updated_at=excluded.updated_at""",
                (user["id"], course_id, active_lesson, len(completed), len(completed) * 100, timestamp),
            )
        self.send_json(200, {"ok": True, "completed": len(completed), "xp": len(completed) * 100})

    def save_quiz_attempt(self) -> None:
        user = self.require_user()
        if not user: return
        payload = self.read_json()
        course_id = str(payload.get("courseId", ""))
        lesson_index = int(payload.get("lessonIndex", -1))
        score = int(payload.get("score", -1))
        if course_id not in COURSE_IDS or not 0 <= lesson_index < 500 or not 0 <= score <= 20:
            raise ValueError("Invalid quiz attempt.")
        with connect() as database:
            database.execute(
                "INSERT INTO quiz_attempts(user_id, course_id, lesson_index, score, question_count, attempted_at) VALUES (?, ?, ?, ?, 20, ?)",
                (user["id"], course_id, lesson_index, score, now()),
            )
        self.send_json(201, {"ok": True})

    def get_leaderboard(self) -> None:
        with connect() as database:
            users = database.execute("SELECT id, username, display_name, created_at FROM users ORDER BY created_at").fetchall()
            progress = database.execute("SELECT user_id, course_id, completed_count, total_lessons, xp, updated_at FROM course_progress").fetchall()
        progress_by_user: dict[int, dict[str, Any]] = {}
        for row in progress:
            progress_by_user.setdefault(row["user_id"], {})[row["course_id"]] = {
                "completed": row["completed_count"], "total": row["total_lessons"], "xp": row["xp"], "updatedAt": row["updated_at"] * 1000,
            }
        entries = []
        for user in users:
            courses = progress_by_user.get(user["id"], {})
            entries.append({
                "name": user["display_name"], "username": user["username"], "createdAt": user["created_at"] * 1000,
                "updatedAt": max((course["updatedAt"] for course in courses.values()), default=0), "courses": courses,
            })
        entries.sort(key=lambda entry: (-sum(course["xp"] for course in entry["courses"].values()), -entry["updatedAt"], entry["username"]))
        self.send_json(200, {"entries": entries})


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Desktopcraft website with its SQLite API.")
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8000")))
    parser.add_argument("--init-only", action="store_true")
    args = parser.parse_args()
    initialize_database()
    if args.init_only:
        print(f"Desktopcraft database ready: {DB_PATH}")
        return
    server = ThreadingHTTPServer((args.host, args.port), DesktopcraftHandler)
    print(f"Desktopcraft server: http://{args.host}:{args.port}")
    print(f"SQLite database: {DB_PATH}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
