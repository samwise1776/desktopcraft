import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Base64;
import java.util.prefs.Preferences;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DesktopcraftApp {
    private static final Color NAV = new Color(23, 37, 31);
    private static final Color NAV_ACTIVE = new Color(42, 67, 56);
    private static final Color CANVAS = new Color(245, 243, 236);
    private static final Color PAPER = new Color(255, 254, 249);
    private static final Color INK = new Color(31, 41, 37);
    private static final Color MUTED = new Color(104, 115, 109);
    private static final Color GREEN = new Color(46, 125, 91);
    private static final Color GREEN_SOFT = new Color(223, 238, 230);
    private static final Color LIME = new Color(216, 239, 114);
    private static final Color ORANGE_SOFT = new Color(255, 240, 228);
    private static final Color EDITOR = new Color(22, 33, 28);
    private static final Color EDITOR_BAR = new Color(32, 46, 39);
    private static final String CUSTOM_LESSON_COUNT_KEY = "custom.lesson.count.v1";
    private static final String CREATION_BAN_KEY = "custom.lesson.creation.banned.v1";
    private static final int PREFERENCE_CHUNK_SIZE = 6000;
    private static final Pattern PROFANITY_PATTERN = Pattern.compile(
        "(?:^|[^a-z0-9])(?:f[\\W_]*u[\\W_]*c[\\W_]*k(?:er|ing|ed|s)?|s[\\W_]*h[\\W_]*i[\\W_]*t(?:ty|s)?|bitch(?:es|ing)?|ass(?:hole|holes|es)?|bastard(?:s)?|cunt(?:s)?|dick(?:s)?|pussy|whore(?:s)?|slut(?:s)?|damn|crap)(?=$|[^a-z0-9])",
        Pattern.CASE_INSENSITIVE
    );

    private final Preferences prefs = Preferences.userNodeForPackage(DesktopcraftApp.class);
    private final List<Course> courses = loadCourses();
    private final Map<String, Set<Integer>> completed = new HashMap<>();
    private final Map<String, Map<Integer, String>> editedCode = new HashMap<>();
    private final Map<String, Integer> builtInLessonCounts = new HashMap<>();

    private JFrame frame;
    private JComboBox<Course> courseBox;
    private JTextField searchField;
    private DefaultListModel<LessonRef> lessonModel;
    private JList<LessonRef> lessonList;
    private JLabel courseTitle;
    private JLabel progressCopy;
    private JLabel xpLabel;
    private JButton userButton;
    private JProgressBar courseProgress;
    private JEditorPane lessonPane;
    private JTextArea codeArea;
    private JPanel previewHost;
    private JLabel consoleLabel;
    private JLabel fileLabel;
    private JButton completeButton;
    private JButton quizButton;
    private JButton previousButton;
    private JButton nextButton;
    private JButton createLessonButton;
    private Course currentCourse;
    private int activeLesson;
    private String currentUserName = "Guest learner";
    private String currentUsername = "";

    public static void main(String[] args) {
        if (args.length > 0 && "--verify".equals(args[0])) {
            List<Course> verifiedCourses = loadCourses();
            int lessonCount = verifiedCourses.stream().mapToInt(course -> course.lessons.size()).sum();
            Lesson creatorLesson = customLesson(verifiedCourses.get(0), "Greeting challenge", "starter", "answer", "Hello, builder!");
            boolean creatorVerified = "starter".equals(creatorLesson.code)
                && "answer".equals(creatorLesson.goal)
                && "Hello, builder!".equals(creatorLesson.starter)
                && containsProfanity("crap")
                && !containsProfanity("class JFrameBuilder");
            AppBlueprint makerTest = new AppBlueprint("Java Swing", "Hello Builder", "Test Window", "Ready", "Run", "Working", 520, 320);
            boolean appMakerVerified = buildMakerSource(makerTest).contains("new JFrame(\"Test Window\")")
                && makerFileName(makerTest).equals("HelloBuilder.java")
                && buildMakerSource(new AppBlueprint("Python Tkinter", "Demo", "Window", "Ready", "Run", "Done", 520, 320)).contains("tk.Tk()")
                && buildMakerSource(new AppBlueprint("C# WinForms", "Demo", "Window", "Ready", "Run", "Done", 520, 320)).contains("Application.Run")
                && buildMakerSource(new AppBlueprint("C++ Qt Widgets", "Demo", "Window", "Ready", "Run", "Done", 520, 320)).contains("QApplication")
                && buildMakerSource(new AppBlueprint("JavaScript Electron", "Demo", "Window", "Ready", "Run", "Done", 520, 320)).contains("BrowserWindow");
            boolean accountFilesVerified = verifyAccountFileSupport();
            boolean curriculumVerified = verifiedCourses.stream().allMatch(course -> course.lessons.size() == 500);
            boolean quizzesVerified = verifiedCourses.stream().allMatch(course -> {
                List<QuizQuestion> questions = buildLessonQuiz(course, 499);
                return questions.size() == 20 && questions.stream().allMatch(question -> question.options.size() == 3 && !question.explanation.isBlank());
            });
            System.out.println("Desktopcraft courses=" + verifiedCourses.size() + " lessons=" + lessonCount + " quizzes=" + (quizzesVerified ? "verified" : "failed") + " creator=" + (creatorVerified ? "verified" : "failed") + " app-maker=" + (appMakerVerified ? "verified" : "failed") + " account-files=" + (accountFilesVerified ? "verified" : "failed"));
            if (verifiedCourses.size() != 5 || lessonCount != 2500 || !curriculumVerified || !quizzesVerified || !creatorVerified || !appMakerVerified || !accountFilesVerified) System.exit(1);
            return;
        }
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            UIManager.put("Label.font", new Font("SansSerif", Font.PLAIN, 13));
            UIManager.put("Button.font", new Font("SansSerif", Font.BOLD, 12));
            new DesktopcraftApp().show();
        });
    }

    private void show() {
        showLoginDialog();
        courses.forEach(course -> builtInLessonCounts.put(course.id, course.lessons.size()));
        loadCustomLessons();
        loadProgress();
        String preferred = prefs.get("activeCourse", "java-swing");
        currentCourse = courses.stream().filter(course -> course.id.equals(preferred)).findFirst().orElse(courses.get(0));
        activeLesson = Math.min(prefs.getInt("activeLesson." + currentCourse.id, 0), currentCourse.lessons.size() - 1);

        frame = new JFrame("Desktopcraft — Desktop App Tutor");
        frame.setIconImages(buildAppIcons());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(1040, 700));
        frame.setSize(1360, 860);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());
        frame.add(buildSidebar(), BorderLayout.WEST);
        frame.add(buildWorkspace(), BorderLayout.CENTER);
        bindKeyboardShortcuts();
        switchCourse(currentCourse, false);
        frame.setVisible(true);
    }

    private JComponent buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(300, 0));
        sidebar.setBackground(NAV);
        sidebar.setLayout(new BorderLayout());
        sidebar.setBorder(new EmptyBorder(22, 16, 18, 16));

        JPanel top = new JPanel();
        top.setOpaque(false);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));

        JLabel brand = new JLabel("  Desktopcraft");
        brand.setOpaque(true);
        brand.setBackground(LIME);
        brand.setForeground(NAV);
        brand.setFont(new Font("SansSerif", Font.BOLD, 18));
        brand.setBorder(new EmptyBorder(10, 9, 10, 9));
        brand.setAlignmentX(Component.LEFT_ALIGNMENT);
        top.add(brand);
        top.add(Box.createVerticalStrut(20));

        JLabel switchLabel = smallLabel("CURRENT COURSE", LIME);
        switchLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        top.add(switchLabel);
        top.add(Box.createVerticalStrut(5));
        courseBox = new JComboBox<>(courses.toArray(new Course[0]));
        courseBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        courseBox.setAlignmentX(Component.LEFT_ALIGNMENT);
        courseBox.addActionListener(event -> {
            Course selected = (Course) courseBox.getSelectedItem();
            if (selected != null && selected != currentCourse) switchCourse(selected, true);
        });
        top.add(courseBox);
        top.add(Box.createVerticalStrut(15));

        progressCopy = new JLabel("0 of 0 lessons");
        progressCopy.setForeground(new Color(173, 188, 178));
        progressCopy.setFont(new Font("SansSerif", Font.PLAIN, 11));
        progressCopy.setAlignmentX(Component.LEFT_ALIGNMENT);
        top.add(progressCopy);
        top.add(Box.createVerticalStrut(5));
        courseProgress = new JProgressBar(0, 100);
        courseProgress.setMaximumSize(new Dimension(Integer.MAX_VALUE, 6));
        courseProgress.setPreferredSize(new Dimension(260, 6));
        courseProgress.setForeground(LIME);
        courseProgress.setBackground(new Color(53, 70, 61));
        courseProgress.setBorderPainted(false);
        courseProgress.setAlignmentX(Component.LEFT_ALIGNMENT);
        top.add(courseProgress);
        top.add(Box.createVerticalStrut(16));

        searchField = new JTextField();
        searchField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        searchField.putClientProperty("JTextField.placeholderText", "Search lessons or APIs…");
        searchField.setAlignmentX(Component.LEFT_ALIGNMENT);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent event) { filterLessons(); }
            public void removeUpdate(DocumentEvent event) { filterLessons(); }
            public void changedUpdate(DocumentEvent event) { filterLessons(); }
        });
        top.add(searchField);
        sidebar.add(top, BorderLayout.NORTH);

        lessonModel = new DefaultListModel<>();
        lessonList = new JList<>(lessonModel);
        lessonList.setBackground(NAV);
        lessonList.setForeground(new Color(188, 201, 192));
        lessonList.setSelectionBackground(NAV_ACTIVE);
        lessonList.setSelectionForeground(Color.WHITE);
        lessonList.setFixedCellHeight(54);
        lessonList.setCellRenderer(new LessonRenderer());
        lessonList.addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting() && lessonList.getSelectedValue() != null) {
                saveCurrentEdit();
                activeLesson = lessonList.getSelectedValue().index;
                showLesson();
            }
        });
        JScrollPane lessonScroll = new JScrollPane(lessonList);
        lessonScroll.setBorder(new EmptyBorder(16, 0, 12, 0));
        lessonScroll.getViewport().setBackground(NAV);
        lessonScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        sidebar.add(lessonScroll, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new GridLayout(4, 1, 0, 8));
        bottom.setOpaque(false);
        createLessonButton = darkButton(prefs.getBoolean(CREATION_BAN_KEY, false) ? "Lesson creation banned" : "+  Create lesson");
        createLessonButton.setEnabled(!prefs.getBoolean(CREATION_BAN_KEY, false));
        createLessonButton.addActionListener(event -> showCreateLessonDialog());
        JButton appMaker = darkButton("🛠  App Maker");
        appMaker.addActionListener(event -> showAppMakerDialog());
        JButton leaderboard = darkButton("🏆  Leaderboard");
        leaderboard.addActionListener(event -> showLeaderboard());
        JButton reset = darkButton("Reset current course");
        reset.addActionListener(event -> resetCourse());
        bottom.add(createLessonButton);
        bottom.add(appMaker);
        bottom.add(leaderboard);
        bottom.add(reset);
        sidebar.add(bottom, BorderLayout.SOUTH);
        return sidebar;
    }

    private JComponent buildWorkspace() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(CANVAS);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(CANVAS);
        header.setBorder(new CompoundBorder(new MatteBorder(0, 0, 1, 0, new Color(222, 222, 213)), new EmptyBorder(15, 25, 15, 25)));
        courseTitle = new JLabel("Desktop course");
        courseTitle.setForeground(INK);
        courseTitle.setFont(new Font("SansSerif", Font.BOLD, 13));
        xpLabel = new JLabel("0 XP");
        xpLabel.setForeground(GREEN);
        xpLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        userButton = secondaryButton(currentUserName);
        userButton.setToolTipText(currentUsername.isBlank() ? "Guest profile" : "@" + currentUsername + " · click to switch account");
        userButton.addActionListener(event -> {
            prefs.remove("session.username");
            prefs.remove("session.email");
            prefs.remove("session.name");
            showLoginDialog();
            userButton.setText(currentUserName);
            userButton.setToolTipText(currentUsername.isBlank() ? "Guest profile" : "@" + currentUsername + " · click to switch account");
        });
        JPanel headerActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        headerActions.setOpaque(false);
        headerActions.add(xpLabel);
        headerActions.add(userButton);
        header.add(courseTitle, BorderLayout.WEST);
        header.add(headerActions, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        lessonPane = new JEditorPane("text/html", "");
        lessonPane.setEditable(false);
        lessonPane.setBackground(PAPER);
        lessonPane.setBorder(new EmptyBorder(16, 16, 16, 16));
        JScrollPane lessonScroll = new JScrollPane(lessonPane);
        lessonScroll.setBorder(new EmptyBorder(0, 0, 0, 0));

        JPanel editorPanel = new JPanel(new BorderLayout());
        editorPanel.setBackground(EDITOR);
        JPanel editorToolbar = new JPanel(new BorderLayout());
        editorToolbar.setBackground(EDITOR_BAR);
        editorToolbar.setBorder(new EmptyBorder(9, 13, 9, 10));
        fileLabel = new JLabel("Main.java");
        fileLabel.setForeground(Color.WHITE);
        fileLabel.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 11));
        JPanel editorActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        editorActions.setOpaque(false);
        JButton copy = toolbarButton("Copy");
        copy.addActionListener(event -> copyCode());
        JButton reset = toolbarButton("Reset");
        reset.addActionListener(event -> resetCode());
        editorActions.add(copy);
        editorActions.add(reset);
        editorToolbar.add(fileLabel, BorderLayout.WEST);
        editorToolbar.add(editorActions, BorderLayout.EAST);
        editorPanel.add(editorToolbar, BorderLayout.NORTH);

        codeArea = new JTextArea();
        codeArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        codeArea.setBackground(EDITOR);
        codeArea.setForeground(new Color(223, 233, 227));
        codeArea.setCaretColor(LIME);
        codeArea.setSelectionColor(GREEN);
        codeArea.setTabSize(4);
        codeArea.setBorder(new EmptyBorder(14, 16, 14, 16));
        JScrollPane codeScroll = new JScrollPane(codeArea);
        codeScroll.setBorder(null);
        editorPanel.add(codeScroll, BorderLayout.CENTER);

        JPanel runBar = new JPanel(new BorderLayout());
        runBar.setBackground(EDITOR_BAR);
        runBar.setBorder(new EmptyBorder(8, 12, 8, 12));
        consoleLabel = new JLabel("Ready. Run the code to update the preview.");
        consoleLabel.setForeground(new Color(161, 177, 167));
        consoleLabel.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 10));
        JButton run = primaryButton("▶  Run code");
        run.addActionListener(event -> runSimulation());
        runBar.add(consoleLabel, BorderLayout.CENTER);
        runBar.add(run, BorderLayout.EAST);
        editorPanel.add(runBar, BorderLayout.SOUTH);

        previewHost = new JPanel(new GridBagLayout());
        previewHost.setBackground(new Color(231, 233, 228));
        previewHost.setBorder(new TitledBorder(new LineBorder(new Color(209, 213, 208)), " Desktop simulator "));

        JSplitPane practiceSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, editorPanel, previewHost);
        practiceSplit.setResizeWeight(0.62);
        practiceSplit.setDividerSize(7);
        practiceSplit.setBorder(null);

        JSplitPane mainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, lessonScroll, practiceSplit);
        mainSplit.setResizeWeight(0.38);
        mainSplit.setDividerSize(7);
        mainSplit.setBorder(new EmptyBorder(20, 22, 12, 22));
        mainSplit.setBackground(CANVAS);
        root.add(mainSplit, BorderLayout.CENTER);

        JPanel navigation = new JPanel(new BorderLayout());
        navigation.setBackground(CANVAS);
        navigation.setBorder(new EmptyBorder(0, 22, 18, 22));
        previousButton = secondaryButton("← Previous");
        previousButton.addActionListener(event -> moveLesson(-1));
        nextButton = secondaryButton("Next →");
        nextButton.addActionListener(event -> moveLesson(1));
        completeButton = primaryButton("Complete lesson ✓");
        completeButton.addActionListener(event -> completeLesson());
        quizButton = secondaryButton("Take lesson quiz");
        quizButton.addActionListener(event -> showLessonQuiz());
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        right.add(quizButton);
        right.add(completeButton);
        right.add(nextButton);
        navigation.add(previousButton, BorderLayout.WEST);
        navigation.add(right, BorderLayout.EAST);
        root.add(navigation, BorderLayout.SOUTH);
        return root;
    }

    private void switchCourse(Course course, boolean savePrevious) {
        if (savePrevious) {
            saveCurrentEdit();
            saveProgress();
        }
        currentCourse = course;
        prefs.put("activeCourse", course.id);
        activeLesson = Math.min(prefs.getInt("activeLesson." + course.id, 0), course.lessons.size() - 1);
        courseBox.setSelectedItem(course);
        searchField.setText("");
        filterLessons();
        showLesson();
    }

    private void filterLessons() {
        if (currentCourse == null || lessonModel == null) return;
        String query = searchField.getText().trim().toLowerCase();
        lessonModel.clear();
        for (int index = 0; index < currentCourse.lessons.size(); index++) {
            Lesson lesson = currentCourse.lessons.get(index);
            String searchable = (lesson.title + " " + lesson.api + " " + lesson.module).toLowerCase();
            if (query.isEmpty() || searchable.contains(query)) lessonModel.addElement(new LessonRef(index, lesson));
        }
        for (int row = 0; row < lessonModel.size(); row++) {
            if (lessonModel.get(row).index == activeLesson) {
                lessonList.setSelectedIndex(row);
                lessonList.ensureIndexIsVisible(row);
                break;
            }
        }
    }

    private void showLesson() {
        Lesson lesson = currentCourse.lessons.get(activeLesson);
        courseTitle.setText(currentCourse.language + "  /  " + simpleLessonText(lesson.module) + "  /  " + lesson.api);
        fileLabel.setText(currentCourse.fileName);
        codeArea.setText(editedCode.getOrDefault(currentCourse.id, Map.of()).getOrDefault(activeLesson, lesson.code));
        codeArea.setCaretPosition(0);
        lessonPane.setText(lessonHtml(lesson));
        lessonPane.setCaretPosition(0);
        renderPreview(codeArea.getText());
        consoleLabel.setText("Ready. Run the code to update the preview.");
        previousButton.setEnabled(activeLesson > 0);
        nextButton.setEnabled(activeLesson < currentCourse.lessons.size() - 1);
        completeButton.setText(isCompleted(activeLesson) ? "Completed ✓" : "Complete lesson ✓");
        quizButton.setText(isCompleted(activeLesson) ? "Retake quiz · complete" : "Take lesson quiz");
        prefs.putInt("activeLesson." + currentCourse.id, activeLesson);
        updateProgress();
    }

    private String lessonHtml(Lesson lesson) {
        if ("Custom lessons".equals(lesson.module)) {
            return "<html><body style='font-family:sans-serif;color:#1f2925;background:#fffef9;padding:20px'>" +
                "<p style='font-size:10px;color:#2e7d5b;font-weight:bold'>CUSTOM LESSON · CREATOR STUDIO</p>" +
                "<h1 style='font-family:serif;font-size:34px;font-weight:normal;margin:8px 0'>" + html(lesson.title) + "</h1>" +
                "<p style='color:#68736d;font-size:14px'>" + html(simpleLessonText(lesson.description)) + "</p>" +
                "<hr style='color:#e5e5dd'><h2 style='font-size:17px'>Build toward the expected result</h2>" +
                "<p>Start with the given code. Change it until it matches the saved answer.</p>" +
                "<div style='background:#dfeee6;padding:12px;margin:18px 0'><b>EXPECTED OUTPUT</b><br>" + html(lesson.starter) + "</div>" +
                "<h2 style='font-size:17px'>Quick challenge</h2>" +
                "<div style='background:#fff0e4;padding:12px'>Make the starter code match the creator's answer, then run it.</div>" +
                "</body></html>";
        }
        return "<html><body style='font-family:sans-serif;color:#1f2925;background:#fffef9;padding:20px'>" +
            "<p style='font-size:10px;color:#2e7d5b;font-weight:bold'>LESSON " + String.format("%03d", activeLesson + 1) + " · " + html(lesson.api) + "</p>" +
            "<h1 style='font-family:serif;font-size:34px;font-weight:normal;margin:8px 0'>" + html(lesson.title) + "</h1>" +
            "<p style='color:#68736d;font-size:14px'>" + html(simpleLessonText(lesson.description)) + "</p>" +
            "<hr style='color:#e5e5dd'><h2 style='font-size:17px'>The big idea</h2>" +
            "<p>Layouts place the controls. Callbacks make the screen react when someone clicks or types.</p>" +
            "<div style='background:#dfeee6;padding:12px;margin:18px 0'><b>HELPFUL TIP</b><br>Keep callbacks short: read the input, change the data, then show the result.</div>" +
            "<h2 style='font-size:17px'>Quick challenge</h2>" +
            "<div style='background:#fff0e4;padding:12px'>Replace <b>" + html(lesson.starter) + "</b> with <b>" + html(lesson.goal) + "</b>, then run the code.</div>" +
            "</body></html>";
    }

    private void runSimulation() {
        String code = codeArea.getText();
        if (!balanced(code, '{', '}') || !balanced(code, '(', ')') || !balanced(code, '[', ']')) {
            consoleLabel.setForeground(new Color(255, 170, 164));
            consoleLabel.setText("Structure check failed: delimiters are unbalanced.");
            return;
        }
        renderPreview(code);
        Lesson lesson = currentCourse.lessons.get(activeLesson);
        boolean passed = "Custom lessons".equals(lesson.module)
            ? normalizeLessonAnswer(code).equals(normalizeLessonAnswer(lesson.goal))
            : code.contains(lesson.goal);
        consoleLabel.setForeground(passed ? LIME : new Color(161, 177, 167));
        consoleLabel.setText(passed && "Custom lessons".equals(lesson.module)
            ? "Answer matched. Expected output: " + lesson.starter
            : passed ? "Challenge complete. Preview updated." : "Simulation ready. Interact with the preview.");
        editedCode.computeIfAbsent(currentCourse.id, ignored -> new HashMap<>()).put(activeLesson, code);
    }

    private void renderPreview(String code) {
        previewHost.removeAll();
        JPanel simulatedWindow = new JPanel(new BorderLayout());
        simulatedWindow.setPreferredSize(new Dimension(400, 180));
        simulatedWindow.setBackground(new Color(244, 244, 244));
        simulatedWindow.setBorder(new CompoundBorder(new LineBorder(new Color(143, 150, 145)), new EmptyBorder(0, 0, 0, 0)));
        JLabel title = new JLabel("  ●  ●  ●                         " + extractTitle(code));
        title.setOpaque(true);
        title.setBackground(new Color(215, 217, 216));
        title.setBorder(new EmptyBorder(7, 8, 7, 8));
        title.setFont(new Font("SansSerif", Font.BOLD, 10));
        simulatedWindow.add(title, BorderLayout.NORTH);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 20));
        controls.setBackground(new Color(244, 244, 244));
        JTextField input = new JTextField("Desktop app", 12);
        JButton action = new JButton("Try " + currentCourse.lessons.get(activeLesson).api);
        JLabel status = new JLabel("Ready");
        action.addActionListener(event -> {
            status.setText(extractResult(code));
            consoleLabel.setText("Desktop event handled in the simulated window.");
        });
        controls.add(input);
        controls.add(action);
        controls.add(status);
        simulatedWindow.add(controls, BorderLayout.CENTER);
        previewHost.add(simulatedWindow);
        previewHost.revalidate();
        previewHost.repaint();
    }

    private String extractTitle(String code) {
        String[] patterns = {
            "new\\s+JFrame\\s*\\(\\s*\"([^\"]*)\"",
            "\\.title\\s*\\(\\s*\"([^\"]*)\"",
            "(?:^|\\s)Text\\s*=\\s*\"([^\"]*)\"",
            "setWindowTitle\\s*\\(\\s*\"([^\"]*)\"",
            "document\\.title\\s*=\\s*\"([^\"]*)\""
        };
        for (String pattern : patterns) {
            Matcher matcher = Pattern.compile(pattern, Pattern.MULTILINE).matcher(code);
            if (matcher.find()) return matcher.group(1);
        }
        return currentCourse.shortTitle + " Preview";
    }

    private String extractResult(String code) {
        String[] patterns = {
            "(?:setText|config)\\s*\\([^\"]*\"([^\"]*)\"",
            "status\\.Text\\s*=\\s*\"([^\"]*)\"",
            "status->setText\\s*\\(\\s*\"([^\"]*)\"",
            "status\\.textContent\\s*=\\s*\"([^\"]*)\""
        };
        String result = currentCourse.lessons.get(activeLesson).starter;
        for (String pattern : patterns) {
            Matcher matcher = Pattern.compile(pattern).matcher(code);
            while (matcher.find()) result = matcher.group(1);
        }
        return result;
    }

    private void completeLesson() {
        completed.computeIfAbsent(currentCourse.id, ignored -> new HashSet<>()).add(activeLesson);
        saveProgress();
        completeButton.setText("Completed ✓");
        updateProgress();
        lessonList.repaint();
        if (activeLesson < currentCourse.lessons.size() - 1) moveLesson(1);
    }

    private void showLessonQuiz() {
        List<QuizQuestion> questions = buildLessonQuiz(currentCourse, activeLesson);
        JDialog dialog = new JDialog(frame, "Lesson quiz · " + currentCourse.lessons.get(activeLesson).title, true);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setLayout(new BorderLayout());
        dialog.getContentPane().setBackground(PAPER);

        JPanel content = new JPanel(new BorderLayout(0, 16));
        content.setBackground(PAPER);
        content.setBorder(new EmptyBorder(22, 24, 20, 24));
        JLabel progress = new JLabel();
        progress.setForeground(GREEN);
        progress.setFont(new Font("SansSerif", Font.BOLD, 11));
        JLabel prompt = new JLabel();
        prompt.setFont(new Font("SansSerif", Font.BOLD, 15));
        JPanel heading = new JPanel();
        heading.setLayout(new BoxLayout(heading, BoxLayout.Y_AXIS));
        heading.setOpaque(false);
        progress.setAlignmentX(Component.LEFT_ALIGNMENT);
        prompt.setAlignmentX(Component.LEFT_ALIGNMENT);
        heading.add(progress);
        heading.add(Box.createVerticalStrut(10));
        heading.add(prompt);
        content.add(heading, BorderLayout.NORTH);

        JPanel optionsPanel = new JPanel();
        optionsPanel.setLayout(new BoxLayout(optionsPanel, BoxLayout.Y_AXIS));
        optionsPanel.setBackground(PAPER);
        content.add(optionsPanel, BorderLayout.CENTER);

        JLabel feedback = new JLabel(" ");
        feedback.setVerticalAlignment(SwingConstants.TOP);
        feedback.setForeground(MUTED);
        JButton check = primaryButton("Check answer");
        JButton next = primaryButton("Next question →");
        next.setVisible(false);
        JButton close = secondaryButton("Close");
        close.addActionListener(event -> dialog.dispose());
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setOpaque(false);
        actions.add(close);
        actions.add(check);
        actions.add(next);
        JPanel footer = new JPanel(new BorderLayout(0, 12));
        footer.setOpaque(false);
        footer.add(feedback, BorderLayout.CENTER);
        footer.add(actions, BorderLayout.SOUTH);
        content.add(footer, BorderLayout.SOUTH);
        dialog.add(content, BorderLayout.CENTER);

        int[] questionIndex = {0};
        int[] score = {0};
        boolean[] answered = {false};
        boolean[] finished = {false};
        ButtonGroup[] currentGroup = {new ButtonGroup()};
        List<JRadioButton> optionButtons = new ArrayList<>();
        Runnable[] renderQuestion = new Runnable[1];
        renderQuestion[0] = () -> {
            QuizQuestion question = questions.get(questionIndex[0]);
            progress.setText("QUESTION " + (questionIndex[0] + 1) + " OF " + questions.size() + "  ·  " + score[0] + " CORRECT");
            prompt.setText("<html><body style='width:540px'>" + html(simpleLessonText(question.question)) + "</body></html>");
            optionsPanel.removeAll();
            currentGroup[0] = new ButtonGroup();
            optionButtons.clear();
            for (int optionIndex = 0; optionIndex < question.options.size(); optionIndex++) {
                JRadioButton option = new JRadioButton("<html><body style='width:500px'>" + html(simpleLessonText(question.options.get(optionIndex))) + "</body></html>");
                option.setActionCommand(String.valueOf(optionIndex));
                option.setBackground(PAPER);
                option.setBorder(new CompoundBorder(new LineBorder(new Color(222, 225, 218)), new EmptyBorder(10, 11, 10, 11)));
                option.setAlignmentX(Component.LEFT_ALIGNMENT);
                option.setMaximumSize(new Dimension(Integer.MAX_VALUE, 82));
                currentGroup[0].add(option);
                optionButtons.add(option);
                optionsPanel.add(option);
                optionsPanel.add(Box.createVerticalStrut(8));
            }
            feedback.setText(" ");
            feedback.setForeground(MUTED);
            check.setVisible(true);
            next.setVisible(false);
            next.setText(questionIndex[0] == questions.size() - 1 ? "Finish quiz →" : "Next question →");
            answered[0] = false;
            optionsPanel.revalidate();
            optionsPanel.repaint();
        };

        check.addActionListener(event -> {
            if (answered[0] || finished[0]) return;
            ButtonModel selected = currentGroup[0].getSelection();
            if (selected == null) {
                feedback.setForeground(new Color(136, 70, 47));
                feedback.setText("Choose an answer before checking.");
                return;
            }
            QuizQuestion question = questions.get(questionIndex[0]);
            int selectedIndex = Integer.parseInt(selected.getActionCommand());
            boolean correct = selectedIndex == question.answer;
            if (correct) score[0]++;
            answered[0] = true;
            for (int index = 0; index < optionButtons.size(); index++) {
                JRadioButton option = optionButtons.get(index);
                option.setEnabled(false);
                if (index == question.answer) option.setBackground(GREEN_SOFT);
                else if (index == selectedIndex) option.setBackground(ORANGE_SOFT);
            }
            progress.setText("QUESTION " + (questionIndex[0] + 1) + " OF " + questions.size() + "  ·  " + score[0] + " CORRECT");
            feedback.setForeground(correct ? GREEN : new Color(136, 70, 47));
            feedback.setText(correct
                ? "<html><body style='width:540px'><b>Correct.</b> " + html(simpleLessonText(question.explanation)) + "</body></html>"
                : "<html><body style='width:540px'><b>Not quite. The correct answer is “" + html(simpleLessonText(question.options.get(question.answer))) + ".”</b><br>" + html(simpleLessonText(question.explanation)) + "</body></html>");
            check.setVisible(false);
            next.setVisible(true);
        });

        next.addActionListener(event -> {
            if (finished[0]) {
                questionIndex[0] = 0;
                score[0] = 0;
                finished[0] = false;
                renderQuestion[0].run();
                return;
            }
            if (!answered[0]) return;
            if (questionIndex[0] < questions.size() - 1) {
                questionIndex[0]++;
                renderQuestion[0].run();
                return;
            }
            finished[0] = true;
            boolean perfect = score[0] == questions.size();
            progress.setText("QUIZ COMPLETE  ·  " + score[0] + " OF " + questions.size() + " CORRECT");
            prompt.setText("<html><body style='width:540px'><b>" + score[0] + " / " + questions.size() + "</b><br>" + (perfect ? "Perfect score—this lesson is complete." : "Review the explanations, then retake the quiz when you are ready.") + "</body></html>");
            optionsPanel.removeAll();
            optionsPanel.revalidate();
            optionsPanel.repaint();
            feedback.setText(perfect ? "Excellent work. You answered every question correctly." : (questions.size() - score[0]) + " answer" + (questions.size() - score[0] == 1 ? "" : "s") + " to revisit.");
            feedback.setForeground(perfect ? GREEN : new Color(136, 70, 47));
            check.setVisible(false);
            next.setText("Retake quiz");
            next.setVisible(true);
            if (perfect) {
                completed.computeIfAbsent(currentCourse.id, ignored -> new HashSet<>()).add(activeLesson);
                saveProgress();
                completeButton.setText("Completed ✓");
                quizButton.setText("Retake quiz · complete");
                updateProgress();
                lessonList.repaint();
            }
        });

        renderQuestion[0].run();
        dialog.setSize(650, 590);
        dialog.setMinimumSize(new Dimension(610, 540));
        dialog.setLocationRelativeTo(frame);
        dialog.setVisible(true);
    }

    private static List<QuizQuestion> buildLessonQuiz(Course course, int lessonIndex) {
        Lesson lesson = course.lessons.get(lessonIndex);
        List<QuizQuestion> questions = new ArrayList<>();
        String[][] prompts = {
            {"Which topic is the focus of this lesson?", "Which API or concept is central to the lesson?", "Which result completes the coding challenge?", "Which curriculum module contains this lesson?", "Which summary describes the active lesson?", "Which response appears in the starter code?"},
            {"Select the title of the lesson you are reviewing.", "Select the API practiced in the code example.", "Select the challenge's required finished result.", "Select the lesson's module.", "Select the matching lesson description.", "Select the starter response before it is edited."},
            {"Review: what is this lesson teaching?", "Review: which API should you recognize?", "Review: what must the response become?", "Review: where is this lesson organized?", "Review: which description matches this work?", "Review: which text is the starting point?"}
        };
        for (int index = 0; index < 18; index++) {
            int valueType = index % 6;
            int round = index / 6;
            String correct = lessonValue(lesson, valueType);
            String explanation = switch (valueType) {
                case 0 -> "The active lesson is titled “" + lesson.title + ".”";
                case 1 -> lesson.api + " is the API or concept named beside this lesson and used by its example.";
                case 2 -> "The challenge asks you to change the response to “" + lesson.goal + ".”";
                case 3 -> "This lesson is organized under the “" + lesson.module + "” module.";
                case 4 -> "This description matches the goal and example shown in the active lesson.";
                default -> "The starter code begins with “" + lesson.starter + "” before the challenge edit.";
            };
            questions.add(quizQuestion(prompts[round][valueType], correct, nearbyLessonValues(course, lessonIndex, valueType, index + 1), lessonIndex + index, explanation));
        }
        questions.add(quizQuestion(
            "Which programming language is used by this course?",
            course.language,
            List.of("Java", "Python", "C#", "C++", "JavaScript"),
            lessonIndex + 18,
            "This course uses " + course.language + " for its editable desktop examples."
        ));
        questions.add(quizQuestion(
            "Which source filename belongs to this course?",
            course.fileName,
            List.of("Main.java", "app.py", "MainForm.cs", "main.cpp", "renderer.js"),
            lessonIndex + 19,
            "The editor labels this course's source file as “" + course.fileName + ".”"
        ));
        return questions;
    }

    private static List<String> nearbyLessonValues(Course course, int lessonIndex, int valueType, int questionOffset) {
        List<String> values = new ArrayList<>();
        values.add(lessonValue(course.lessons.get(lessonIndex), valueType));
        for (int step = 1; values.size() < 3 && step < course.lessons.size() + 2; step++) {
            int index = Math.floorMod(lessonIndex + questionOffset + step * 7, course.lessons.size());
            String value = lessonValue(course.lessons.get(index), valueType);
            if (!value.isBlank() && !values.contains(value)) values.add(value);
        }
        for (String fallback : List.of("A different desktop concept", "An unrelated project step", "A separate toolkit feature")) {
            if (values.size() < 3 && !values.contains(fallback)) values.add(fallback);
        }
        return values;
    }

    private static String lessonValue(Lesson lesson, int valueType) {
        return switch (valueType) {
            case 0 -> lesson.title;
            case 1 -> lesson.api;
            case 2 -> lesson.goal;
            case 3 -> lesson.module;
            case 4 -> lesson.description;
            default -> lesson.starter;
        };
    }

    private static QuizQuestion quizQuestion(String prompt, String correct, List<String> values, int rotation, String explanation) {
        List<String> options = new ArrayList<>();
        options.add(correct);
        for (String value : values) if (!options.contains(value) && options.size() < 3) options.add(value);
        while (options.size() < 3) options.add("Alternative " + (options.size() + 1));
        int shift = Math.floorMod(rotation, options.size());
        List<String> rotated = new ArrayList<>();
        rotated.addAll(options.subList(shift, options.size()));
        rotated.addAll(options.subList(0, shift));
        return new QuizQuestion(prompt, rotated, rotated.indexOf(correct), explanation);
    }

    private void moveLesson(int delta) {
        saveCurrentEdit();
        activeLesson = Math.max(0, Math.min(activeLesson + delta, currentCourse.lessons.size() - 1));
        filterLessons();
        showLesson();
    }

    private void updateProgress() {
        int count = completed.getOrDefault(currentCourse.id, Set.of()).size();
        int percent = Math.round(count * 100f / currentCourse.lessons.size());
        progressCopy.setText(count + " of " + currentCourse.lessons.size() + " lessons");
        courseProgress.setValue(percent);
        int totalLessons = courses.stream().mapToInt(course -> course.lessons.size()).sum();
        xpLabel.setText(totalCompleted() * 100 + " XP  ·  " + totalCompleted() + " / " + totalLessons + " lessons");
    }

    private void showLeaderboard() {
        saveProgress();
        List<Builder> builders = new ArrayList<>();
        Set<String> usernames = new HashSet<>();
        try {
            for (String key : prefs.keys()) {
                if (!key.startsWith("account.") || !key.endsWith(".username")) continue;
                String id = key.substring("account.".length(), key.length() - ".username".length());
                String username = prefs.get(key, "");
                String name = prefs.get("account." + id + ".name", username);
                if (!username.isBlank() && usernames.add(username)) builders.add(leaderboardBuilder(name, username));
            }
        } catch (Exception ignored) {
            // The current signed-in account can still be shown if preference enumeration is unavailable.
        }
        if (!currentUsername.isBlank() && usernames.add(currentUsername)) {
            builders.add(leaderboardBuilder(currentUserName, currentUsername));
        }
        if (builders.isEmpty()) {
            JOptionPane.showMessageDialog(
                frame,
                "Create a Desktopcraft account and complete a lesson to claim the first leaderboard spot.\nNo sample builders or invented scores are used.",
                "Desktopcraft Real Account Leaderboard",
                JOptionPane.INFORMATION_MESSAGE
            );
            return;
        }
        builders.sort(Comparator.comparingInt(Builder::xp).reversed().thenComparing(Builder::username));
        String[] columns = {"Rank", "Builder", "Username", "Focus", "XP"};
        Object[][] rows = new Object[builders.size()][5];
        for (int index = 0; index < builders.size(); index++) {
            Builder builder = builders.get(index);
            rows[index] = new Object[]{index + 1, builder.name, "@" + builder.username, builder.focus, String.format("%,d", builder.xp)};
        }
        JTable table = new JTable(rows, columns);
        table.setRowHeight(30);
        table.setEnabled(false);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setPreferredSize(new Dimension(720, Math.min(420, 68 + builders.size() * 30)));
        JOptionPane.showMessageDialog(frame, scroll, "Desktopcraft Real Account Leaderboard", JOptionPane.PLAIN_MESSAGE);
    }

    private Builder leaderboardBuilder(String name, String username) {
        String id = accountId(username);
        int total = 0;
        int strongestCount = 0;
        String focus = "Start a course";
        for (Course course : courses) {
            int courseCompleted = Math.max(0, Math.min(500, prefs.getInt("leaderboard." + id + ".completed." + course.id, 0)));
            total += courseCompleted;
            if (courseCompleted > strongestCount) {
                strongestCount = courseCompleted;
                focus = course.shortTitle;
            }
        }
        return new Builder(name, username, focus, total * 100);
    }

    private String strongestCourse() {
        return courses.stream().max(Comparator.comparingInt(course -> completed.getOrDefault(course.id, Set.of()).size()))
            .map(course -> course.shortTitle).orElse("Start a course");
    }

    private int totalCompleted() {
        return completed.values().stream().mapToInt(Set::size).sum();
    }

    private boolean isCompleted(int index) {
        return completed.getOrDefault(currentCourse.id, Set.of()).contains(index);
    }

    private void resetCourse() {
        int answer = JOptionPane.showConfirmDialog(frame, "Reset progress and edited code for " + currentCourse.shortTitle + "?", "Reset course", JOptionPane.YES_NO_OPTION);
        if (answer != JOptionPane.YES_OPTION) return;
        completed.remove(currentCourse.id);
        editedCode.remove(currentCourse.id);
        prefs.remove("completed." + currentCourse.id);
        activeLesson = 0;
        saveProgress();
        filterLessons();
        showLesson();
    }

    private void resetCode() {
        editedCode.getOrDefault(currentCourse.id, new HashMap<>()).remove(activeLesson);
        codeArea.setText(currentCourse.lessons.get(activeLesson).code);
        renderPreview(codeArea.getText());
        consoleLabel.setText("Starter code restored.");
    }

    private void copyCode() {
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(codeArea.getText()), null);
        consoleLabel.setText(currentCourse.language + " code copied to the clipboard.");
    }

    private void saveCurrentEdit() {
        if (currentCourse == null || codeArea == null) return;
        editedCode.computeIfAbsent(currentCourse.id, ignored -> new HashMap<>()).put(activeLesson, codeArea.getText());
    }

    private void showAppMakerDialog() {
        JDialog dialog = new JDialog(frame, "Desktopcraft App Maker", true);
        dialog.setIconImages(buildAppIcons());
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setSize(1120, 760);
        dialog.setMinimumSize(new Dimension(900, 640));
        dialog.setLocationRelativeTo(frame);

        JComboBox<String> toolkitBox = new JComboBox<>(new String[]{"Java Swing", "Python Tkinter", "C# WinForms", "C++ Qt Widgets", "JavaScript Electron"});
        JTextField appNameField = new JTextField("Hello Builder", 24);
        JTextField titleField = new JTextField("My Desktop App", 24);
        JTextField messageField = new JTextField("Ready to build something great.", 24);
        JTextField buttonField = new JTextField("Launch", 24);
        JTextField actionField = new JTextField("Your desktop app is working!", 24);
        JSpinner widthSpinner = new JSpinner(new SpinnerNumberModel(520, 320, 1200, 10));
        JSpinner heightSpinner = new JSpinner(new SpinnerNumberModel(320, 220, 900, 10));

        JPanel controls = new JPanel();
        controls.setLayout(new BoxLayout(controls, BoxLayout.Y_AXIS));
        controls.setBackground(PAPER);
        controls.setBorder(new EmptyBorder(22, 22, 22, 22));
        JLabel kicker = smallLabel("DESKTOP APP WORKSHOP", GREEN);
        kicker.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel heading = new JLabel("Build an app starter");
        heading.setFont(new Font("Serif", Font.PLAIN, 27));
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel description = new JLabel("<html><span style='color:#68736d'>Choose a toolkit, edit the blueprint,<br>then copy or save the generated source.</span></html>");
        description.setAlignmentX(Component.LEFT_ALIGNMENT);
        controls.add(kicker);
        controls.add(Box.createVerticalStrut(3));
        controls.add(heading);
        controls.add(Box.createVerticalStrut(4));
        controls.add(description);
        controls.add(Box.createVerticalStrut(18));
        addMakerControl(controls, "Desktop toolkit", toolkitBox);
        addMakerControl(controls, "App name", appNameField);
        addMakerControl(controls, "Window title", titleField);
        addMakerControl(controls, "Starting message", messageField);
        addMakerControl(controls, "Button label", buttonField);
        addMakerControl(controls, "Message after click", actionField);
        JPanel dimensions = new JPanel(new GridLayout(1, 2, 8, 0));
        dimensions.setOpaque(false);
        dimensions.add(labeledMakerComponent("WIDTH", widthSpinner));
        dimensions.add(labeledMakerComponent("HEIGHT", heightSpinner));
        dimensions.setMaximumSize(new Dimension(Integer.MAX_VALUE, 58));
        dimensions.setAlignmentX(Component.LEFT_ALIGNMENT);
        controls.add(dimensions);
        controls.add(Box.createVerticalGlue());
        JLabel localNote = new JLabel("Generated locally · No source is uploaded");
        localNote.setForeground(MUTED);
        localNote.setFont(new Font("SansSerif", Font.PLAIN, 9));
        localNote.setAlignmentX(Component.LEFT_ALIGNMENT);
        controls.add(localNote);

        JTextArea generatedArea = new JTextArea();
        generatedArea.setEditable(false);
        generatedArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        generatedArea.setForeground(new Color(220, 231, 224));
        generatedArea.setBackground(EDITOR);
        generatedArea.setCaretColor(Color.WHITE);
        generatedArea.setBorder(new EmptyBorder(14, 16, 14, 16));
        JScrollPane codeScroll = new JScrollPane(generatedArea);
        codeScroll.setBorder(null);

        JLabel generatedFile = new JLabel("HelloBuilder.java");
        generatedFile.setForeground(Color.WHITE);
        generatedFile.setFont(new Font("Monospaced", Font.BOLD, 11));
        JPanel codeHeader = new JPanel(new BorderLayout());
        codeHeader.setBackground(EDITOR_BAR);
        codeHeader.setBorder(new EmptyBorder(10, 14, 10, 14));
        codeHeader.add(generatedFile, BorderLayout.WEST);
        JPanel codeCard = new JPanel(new BorderLayout());
        codeCard.setBackground(EDITOR);
        codeCard.add(codeHeader, BorderLayout.NORTH);
        codeCard.add(codeScroll, BorderLayout.CENTER);

        JPanel previewStage = new JPanel(new GridBagLayout());
        previewStage.setBackground(new Color(235, 238, 232));
        previewStage.setBorder(new EmptyBorder(18, 18, 18, 18));
        JLabel previewTitle = new JLabel("  ●  ●  ●                         My Desktop App");
        previewTitle.setOpaque(true);
        previewTitle.setBackground(new Color(218, 222, 218));
        previewTitle.setBorder(new EmptyBorder(7, 9, 7, 9));
        previewTitle.setFont(new Font("SansSerif", Font.BOLD, 10));
        JLabel previewToolkit = smallLabel("JAVA SWING", GREEN);
        JLabel previewAppName = new JLabel("Hello Builder");
        previewAppName.setFont(new Font("Serif", Font.PLAIN, 25));
        JLabel previewMessage = new JLabel("Ready to build something great.");
        previewMessage.setForeground(MUTED);
        JButton previewAction = primaryButton("Launch");
        JPanel previewBody = new JPanel();
        previewBody.setLayout(new BoxLayout(previewBody, BoxLayout.Y_AXIS));
        previewBody.setBackground(new Color(248, 248, 246));
        previewBody.setBorder(new EmptyBorder(24, 34, 24, 34));
        for (JComponent component : new JComponent[]{previewToolkit, previewAppName, previewMessage, previewAction}) {
            component.setAlignmentX(Component.CENTER_ALIGNMENT);
            previewBody.add(component);
            previewBody.add(Box.createVerticalStrut(9));
        }
        JPanel previewWindow = new JPanel(new BorderLayout());
        previewWindow.setPreferredSize(new Dimension(470, 230));
        previewWindow.setBorder(new LineBorder(new Color(150, 158, 153)));
        previewWindow.add(previewTitle, BorderLayout.NORTH);
        previewWindow.add(previewBody, BorderLayout.CENTER);
        previewStage.add(previewWindow);

        JPanel right = new JPanel(new BorderLayout(0, 10));
        right.setBackground(CANVAS);
        right.setBorder(new EmptyBorder(14, 14, 14, 14));
        JSplitPane outputSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, codeCard, previewStage);
        outputSplit.setResizeWeight(0.58);
        outputSplit.setBorder(null);
        right.add(outputSplit, BorderLayout.CENTER);

        JButton copyButton = secondaryButton("Copy code");
        JButton saveButton = primaryButton("Save source…");
        JButton closeButton = secondaryButton("Close");
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setOpaque(false);
        actions.add(copyButton);
        actions.add(saveButton);
        actions.add(closeButton);
        right.add(actions, BorderLayout.SOUTH);

        Runnable refresh = () -> {
            AppBlueprint blueprint = new AppBlueprint(
                String.valueOf(toolkitBox.getSelectedItem()),
                appNameField.getText().trim().isEmpty() ? "Desktop App" : appNameField.getText().trim(),
                titleField.getText().trim().isEmpty() ? "My Desktop App" : titleField.getText().trim(),
                messageField.getText().trim().isEmpty() ? "Ready." : messageField.getText().trim(),
                buttonField.getText().trim().isEmpty() ? "Run" : buttonField.getText().trim(),
                actionField.getText().trim().isEmpty() ? "It works!" : actionField.getText().trim(),
                (Integer) widthSpinner.getValue(),
                (Integer) heightSpinner.getValue()
            );
            generatedArea.setText(buildMakerSource(blueprint));
            generatedArea.setCaretPosition(0);
            generatedFile.setText(makerFileName(blueprint));
            previewToolkit.setText(blueprint.toolkit.toUpperCase(Locale.ROOT));
            previewAppName.setText(blueprint.appName);
            previewMessage.setText(blueprint.message);
            previewAction.setText(blueprint.buttonLabel);
            previewTitle.setText("  ●  ●  ●                         " + blueprint.windowTitle);
            previewWindow.setPreferredSize(new Dimension(Math.min(650, blueprint.width), Math.min(360, blueprint.height)));
            previewStage.revalidate();
        };

        DocumentListener liveRefresh = new DocumentListener() {
            public void insertUpdate(DocumentEvent event) { refresh.run(); }
            public void removeUpdate(DocumentEvent event) { refresh.run(); }
            public void changedUpdate(DocumentEvent event) { refresh.run(); }
        };
        for (JTextField field : new JTextField[]{appNameField, titleField, messageField, buttonField, actionField}) {
            field.getDocument().addDocumentListener(liveRefresh);
        }
        toolkitBox.addActionListener(event -> refresh.run());
        widthSpinner.addChangeListener(event -> refresh.run());
        heightSpinner.addChangeListener(event -> refresh.run());
        previewAction.addActionListener(event -> previewMessage.setText(actionField.getText().trim().isEmpty() ? "It works!" : actionField.getText().trim()));
        copyButton.addActionListener(event -> {
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(generatedArea.getText()), null);
            copyButton.setText("Copied ✓");
            Timer timer = new Timer(1400, resetEvent -> copyButton.setText("Copy code"));
            timer.setRepeats(false);
            timer.start();
        });
        saveButton.addActionListener(event -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Save generated app source");
            chooser.setSelectedFile(new File(generatedFile.getText()));
            if (chooser.showSaveDialog(dialog) != JFileChooser.APPROVE_OPTION) return;
            try {
                Files.writeString(chooser.getSelectedFile().toPath(), generatedArea.getText(), StandardCharsets.UTF_8);
                JOptionPane.showMessageDialog(dialog, "Saved " + chooser.getSelectedFile().getName(), "Source saved", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException exception) {
                JOptionPane.showMessageDialog(dialog, "Could not save the source: " + exception.getMessage(), "Save failed", JOptionPane.ERROR_MESSAGE);
            }
        });
        closeButton.addActionListener(event -> dialog.dispose());

        JSplitPane layout = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, controls, right);
        layout.setDividerLocation(340);
        layout.setResizeWeight(0);
        layout.setBorder(null);
        dialog.setContentPane(layout);
        refresh.run();
        dialog.setVisible(true);
    }

    private static void addMakerControl(JPanel panel, String label, JComponent component) {
        JLabel fieldLabel = new JLabel(label.toUpperCase(Locale.ROOT));
        fieldLabel.setForeground(MUTED);
        fieldLabel.setFont(new Font("SansSerif", Font.BOLD, 9));
        fieldLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        component.setAlignmentX(Component.LEFT_ALIGNMENT);
        component.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        panel.add(fieldLabel);
        panel.add(Box.createVerticalStrut(4));
        panel.add(component);
        panel.add(Box.createVerticalStrut(10));
    }

    private static JPanel labeledMakerComponent(String label, JComponent component) {
        JPanel panel = new JPanel(new BorderLayout(0, 4));
        panel.setOpaque(false);
        JLabel copy = smallLabel(label, MUTED);
        panel.add(copy, BorderLayout.NORTH);
        panel.add(component, BorderLayout.CENTER);
        return panel;
    }

    private static String buildMakerSource(AppBlueprint values) {
        String name = makerEscape(values.appName);
        String title = makerEscape(values.windowTitle);
        String message = makerEscape(values.message);
        String button = makerEscape(values.buttonLabel);
        String action = makerEscape(values.actionMessage);
        String className = makerClassName(values.appName);
        return switch (values.toolkit) {
            case "Python Tkinter" -> """
                import tkinter as tk
                from tkinter import ttk

                root = tk.Tk()
                root.title("%s")
                root.geometry("%dx%d")

                content = ttk.Frame(root, padding=32)
                content.pack(fill="both", expand=True)
                ttk.Label(content, text="%s", font=("TkDefaultFont", 18, "bold")).pack(pady=8)
                message = ttk.Label(content, text="%s")
                message.pack(pady=12)

                def handle_action():
                    message.config(text="%s")

                ttk.Button(content, text="%s", command=handle_action).pack(pady=8)
                root.mainloop()
                """.formatted(title, values.width, values.height, name, message, action, button);
            case "C# WinForms" -> """
                using System;
                using System.Drawing;
                using System.Windows.Forms;

                public class %s : Form
                {
                    private readonly Label message = new();

                    public %s()
                    {
                        Text = "%s";
                        ClientSize = new Size(%d, %d);
                        StartPosition = FormStartPosition.CenterScreen;
                        var heading = new Label { Text = "%s", AutoSize = true };
                        message.Text = "%s";
                        message.AutoSize = true;
                        var action = new Button { Text = "%s", AutoSize = true };
                        action.Click += (_, _) => message.Text = "%s";
                        var layout = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, Padding = new Padding(32) };
                        layout.Controls.AddRange(new Control[] { heading, message, action });
                        Controls.Add(layout);
                    }

                    [STAThread]
                    public static void Main()
                    {
                        ApplicationConfiguration.Initialize();
                        Application.Run(new %s());
                    }
                }
                """.formatted(className, className, title, values.width, values.height, name, message, button, action, className);
            case "C++ Qt Widgets" -> """
                #include <QApplication>
                #include <QLabel>
                #include <QPushButton>
                #include <QVBoxLayout>
                #include <QWidget>

                int main(int argc, char *argv[]) {
                    QApplication app(argc, argv);
                    QWidget window;
                    window.setWindowTitle("%s");
                    window.resize(%d, %d);
                    auto *heading = new QLabel("%s");
                    auto *message = new QLabel("%s");
                    auto *action = new QPushButton("%s");
                    auto *layout = new QVBoxLayout(&window);
                    layout->addWidget(heading);
                    layout->addWidget(message);
                    layout->addWidget(action);
                    QObject::connect(action, &QPushButton::clicked, [message]() {
                        message->setText("%s");
                    });
                    window.show();
                    return app.exec();
                }
                """.formatted(title, values.width, values.height, name, message, button, action);
            case "JavaScript Electron" -> {
                String safeAction = makerEscape(values.actionMessage).replace("</script", "<\\/script");
                String page = "<!doctype html><html><body style='font-family:system-ui;display:grid;place-items:center;height:100vh;margin:0'><main style='text-align:center'><h1>" + makerHtml(values.appName) + "</h1><p id='message'>" + makerHtml(values.message) + "</p><button id='action'>" + makerHtml(values.buttonLabel) + "</button></main><script>document.querySelector('#action').addEventListener('click',()=>document.querySelector('#message').textContent=\"" + safeAction + "\")<" + "/script></body></html>";
                yield """
                    const { app, BrowserWindow } = require("electron");

                    function createWindow() {
                        const window = new BrowserWindow({ width: %d, height: %d, title: "%s" });
                        const page = "%s";
                        window.loadURL("data:text/html;charset=utf-8," + encodeURIComponent(page));
                    }

                    app.whenReady().then(createWindow);
                    app.on("window-all-closed", () => {
                        if (process.platform !== "darwin") app.quit();
                    });
                    """.formatted(values.width, values.height, title, makerEscape(page));
            }
            default -> """
                import javax.swing.*;
                import java.awt.*;

                public class %s {
                    public static void main(String[] args) {
                        SwingUtilities.invokeLater(() -> {
                            JFrame frame = new JFrame("%s");
                            JLabel heading = new JLabel("%s", SwingConstants.CENTER);
                            JLabel message = new JLabel("%s", SwingConstants.CENTER);
                            JButton action = new JButton("%s");
                            heading.setFont(heading.getFont().deriveFont(Font.BOLD, 22f));
                            action.addActionListener(event -> message.setText("%s"));
                            JPanel content = new JPanel(new GridLayout(3, 1, 8, 8));
                            content.setBorder(BorderFactory.createEmptyBorder(28, 36, 28, 36));
                            content.add(heading);
                            content.add(message);
                            content.add(action);
                            frame.setContentPane(content);
                            frame.setSize(%d, %d);
                            frame.setLocationRelativeTo(null);
                            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                            frame.setVisible(true);
                        });
                    }
                }
                """.formatted(className, title, name, message, button, action, values.width, values.height);
        };
    }

    private static String makerFileName(AppBlueprint values) {
        String extension = switch (values.toolkit) {
            case "Python Tkinter" -> "py";
            case "C# WinForms" -> "cs";
            case "C++ Qt Widgets" -> "cpp";
            case "JavaScript Electron" -> "js";
            default -> "java";
        };
        return makerClassName(values.appName) + "." + extension;
    }

    private static String makerClassName(String value) {
        StringBuilder result = new StringBuilder();
        for (String part : value.split("[^A-Za-z0-9]+")) {
            if (part.isEmpty()) continue;
            result.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        if (result.isEmpty()) result.append("DesktopApp");
        if (Character.isDigit(result.charAt(0))) result.insert(0, "App");
        return result.toString();
    }

    private static String makerEscape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", "").replace("\n", "\\n");
    }

    private static String makerHtml(String value) {
        return html(value).replace("'", "&#039;");
    }

    private void showCreateLessonDialog() {
        if (prefs.getBoolean(CREATION_BAN_KEY, false)) {
            JOptionPane.showMessageDialog(frame, "Lesson creation is banned on this local app profile.", "Creation unavailable", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JTextField nameField = new JTextField(36);
        JTextArea starterArea = creatorTextArea(7, true);
        JTextArea answerArea = creatorTextArea(7, true);
        JTextArea outputArea = creatorTextArea(4, false);
        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBorder(new EmptyBorder(8, 10, 8, 10));

        JLabel heading = new JLabel("<html><b>Create a " + html(currentCourse.shortTitle) + " lesson</b><br><span style='color:#68736d'>Write the lesson name, starter code, answer, and expected output yourself.</span></html>");
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);
        fields.add(heading);
        fields.add(Box.createVerticalStrut(10));
        JLabel warning = new JLabel("<html><div style='background:#fff0e4;padding:8px;color:#68392e'><b>Profanity-free studio</b><br>Submitting profanity permanently disables creation on this app profile and erases every custom lesson and this draft.</div></html>");
        warning.setAlignmentX(Component.LEFT_ALIGNMENT);
        fields.add(warning);
        fields.add(Box.createVerticalStrut(12));
        addCreatorField(fields, "Lesson name", nameField);
        addCreatorField(fields, "Starter code", new JScrollPane(starterArea));
        addCreatorField(fields, "Answer", new JScrollPane(answerArea));
        addCreatorField(fields, "Expected output", new JScrollPane(outputArea));

        JScrollPane formScroll = new JScrollPane(fields);
        formScroll.setPreferredSize(new Dimension(700, 610));
        formScroll.setBorder(null);
        int choice = JOptionPane.showConfirmDialog(
            frame,
            formScroll,
            "Desktopcraft Lesson Studio",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE,
            new ImageIcon(buildAppIcon(48))
        );
        if (choice != JOptionPane.OK_OPTION) return;

        String name = nameField.getText().trim();
        String starterCode = starterArea.getText().trim();
        String answer = answerArea.getText().trim();
        String expectedOutput = outputArea.getText().trim();
        if (name.isBlank() || starterCode.isBlank() || answer.isBlank() || expectedOutput.isBlank()) {
            showCreatorError("Complete the lesson name, starter code, answer, and expected output.");
            return;
        }
        if (name.length() > 80 || starterCode.length() > 12000 || answer.length() > 12000 || expectedOutput.length() > 1000) {
            showCreatorError("Lesson content is too long. Keep the name under 80 characters, code fields under 12,000, and output under 1,000.");
            return;
        }
        if (containsProfanity(name, starterCode, answer, expectedOutput)) {
            nameField.setText("");
            starterArea.setText("");
            answerArea.setText("");
            outputArea.setText("");
            eraseCustomLessonsAndBan();
            JOptionPane.showMessageDialog(
                frame,
                "Profanity was detected. All custom lessons and this draft were erased, and lesson creation is now banned on this app profile.",
                "Lesson creation banned",
                JOptionPane.ERROR_MESSAGE,
                new ImageIcon(buildAppIcon(32))
            );
            return;
        }

        Lesson lesson = customLesson(currentCourse, name, starterCode, answer, expectedOutput);
        saveCustomLessonRecord(currentCourse.id, name, starterCode, answer, expectedOutput);
        currentCourse.lessons.add(lesson);
        activeLesson = currentCourse.lessons.size() - 1;
        filterLessons();
        showLesson();
        JOptionPane.showMessageDialog(frame, "Your custom lesson was published to " + currentCourse.shortTitle + ".", "Lesson published", JOptionPane.INFORMATION_MESSAGE);
    }

    private static JTextArea creatorTextArea(int rows, boolean code) {
        JTextArea area = new JTextArea(rows, 52);
        area.setLineWrap(!code);
        area.setWrapStyleWord(!code);
        area.setTabSize(4);
        if (code) area.setFont(new Font("Monospaced", Font.PLAIN, 12));
        return area;
    }

    private void showCreatorError(String message) {
        JOptionPane.showMessageDialog(frame, message, "Could not create lesson", JOptionPane.ERROR_MESSAGE, new ImageIcon(buildAppIcon(32)));
    }

    private static void addCreatorField(JPanel fields, String label, JComponent component) {
        JLabel fieldLabel = new JLabel(label);
        fieldLabel.setFont(new Font("SansSerif", Font.BOLD, 11));
        fieldLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        component.setAlignmentX(Component.LEFT_ALIGNMENT);
        component.setMaximumSize(new Dimension(Integer.MAX_VALUE, component instanceof JScrollPane ? 150 : 34));
        fields.add(fieldLabel);
        fields.add(Box.createVerticalStrut(4));
        fields.add(component);
        fields.add(Box.createVerticalStrut(10));
    }

    private static Lesson customLesson(Course course, String name, String starterCode, String answer, String expectedOutput) {
        return new Lesson(
            "Custom lessons",
            name,
            "Creator lesson",
            "A custom " + course.shortTitle + " challenge created in the Desktopcraft lesson studio. Expected output: " + expectedOutput,
            expectedOutput,
            answer,
            starterCode
        );
    }

    private static boolean containsProfanity(String... values) {
        for (String value : values) {
            String normalized = Normalizer.normalize(value, Normalizer.Form.NFKD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .replace('0', 'o')
                .replace('1', 'i')
                .replace('3', 'e')
                .replace('4', 'a')
                .replace('5', 's')
                .replace('7', 't');
            if (PROFANITY_PATTERN.matcher(normalized).find()) return true;
        }
        return false;
    }

    private void saveCustomLessonRecord(String courseId, String name, String starterCode, String answer, String expectedOutput) {
        int index = prefs.getInt(CUSTOM_LESSON_COUNT_KEY, 0);
        String serialized = courseId + "\t" + encodeField(name) + "\t" + encodeField(starterCode) + "\t" + encodeField(answer) + "\t" + encodeField(expectedOutput);
        String prefix = "custom.lesson.v1." + index + ".";
        int chunks = Math.max(1, (serialized.length() + PREFERENCE_CHUNK_SIZE - 1) / PREFERENCE_CHUNK_SIZE);
        prefs.putInt(prefix + "chunks", chunks);
        for (int chunk = 0; chunk < chunks; chunk++) {
            int start = chunk * PREFERENCE_CHUNK_SIZE;
            prefs.put(prefix + chunk, serialized.substring(start, Math.min(serialized.length(), start + PREFERENCE_CHUNK_SIZE)));
        }
        prefs.putInt(CUSTOM_LESSON_COUNT_KEY, index + 1);
    }

    private void loadCustomLessons() {
        int count = prefs.getInt(CUSTOM_LESSON_COUNT_KEY, 0);
        for (int index = 0; index < count; index++) {
            String prefix = "custom.lesson.v1." + index + ".";
            int chunks = prefs.getInt(prefix + "chunks", 0);
            StringBuilder serialized = new StringBuilder();
            for (int chunk = 0; chunk < chunks; chunk++) serialized.append(prefs.get(prefix + chunk, ""));
            String[] fields = serialized.toString().split("\\t", -1);
            if (fields.length != 5) continue;
            Course course = courses.stream().filter(candidate -> candidate.id.equals(fields[0])).findFirst().orElse(null);
            if (course == null) continue;
            try {
                String name = decodeField(fields[1]);
                String starterCode = decodeField(fields[2]);
                String answer = decodeField(fields[3]);
                String expectedOutput = decodeField(fields[4]);
                if (!name.isBlank() && !starterCode.isBlank() && !answer.isBlank() && !expectedOutput.isBlank()) {
                    course.lessons.add(customLesson(course, name, starterCode, answer, expectedOutput));
                }
            } catch (IllegalArgumentException ignored) {
                // Ignore a malformed local record and keep the built-in catalog available.
            }
        }
    }

    private void eraseCustomLessonsAndBan() {
        prefs.putBoolean(CREATION_BAN_KEY, true);
        int count = prefs.getInt(CUSTOM_LESSON_COUNT_KEY, 0);
        for (int index = 0; index < count; index++) {
            String prefix = "custom.lesson.v1." + index + ".";
            int chunks = prefs.getInt(prefix + "chunks", 0);
            for (int chunk = 0; chunk < chunks; chunk++) prefs.remove(prefix + chunk);
            prefs.remove(prefix + "chunks");
        }
        prefs.remove(CUSTOM_LESSON_COUNT_KEY);

        for (Course course : courses) {
            int builtInCount = builtInLessonCounts.getOrDefault(course.id, course.lessons.size());
            if (course.lessons.size() > builtInCount) course.lessons.subList(builtInCount, course.lessons.size()).clear();
            completed.computeIfAbsent(course.id, ignored -> new HashSet<>()).removeIf(index -> index >= builtInCount);
            editedCode.computeIfAbsent(course.id, ignored -> new HashMap<>()).keySet().removeIf(index -> index >= builtInCount);
            String stored = completed.get(course.id).stream().sorted().map(String::valueOf).reduce((left, right) -> left + "," + right).orElse("");
            prefs.put("completed." + course.id, stored);
            prefs.putInt("activeLesson." + course.id, Math.min(prefs.getInt("activeLesson." + course.id, 0), builtInCount - 1));
        }

        activeLesson = Math.min(activeLesson, currentCourse.lessons.size() - 1);
        createLessonButton.setText("Lesson creation banned");
        createLessonButton.setEnabled(false);
        filterLessons();
        showLesson();
    }

    private static String encodeField(String value) {
        return Base64.getUrlEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private static String decodeField(String value) {
        return new String(Base64.getUrlDecoder().decode(value), StandardCharsets.UTF_8);
    }

    private void loadProgress() {
        for (Course course : courses) {
            Set<Integer> values = new HashSet<>();
            String stored = prefs.get("completed." + course.id, "");
            for (String value : stored.split(",")) {
                try {
                    if (!value.isBlank()) values.add(Integer.parseInt(value));
                } catch (NumberFormatException ignored) {
                }
            }
            completed.put(course.id, values);
        }
    }

    private void saveProgress() {
        Set<Integer> values = completed.getOrDefault(currentCourse.id, Set.of());
        String stored = values.stream().sorted().map(String::valueOf).reduce((left, right) -> left + "," + right).orElse("");
        prefs.put("completed." + currentCourse.id, stored);
        prefs.putInt("activeLesson." + currentCourse.id, activeLesson);
        if (!currentUsername.isBlank()) {
            String id = accountId(currentUsername);
            prefs.put("leaderboard." + id + ".name", currentUserName);
            prefs.put("leaderboard." + id + ".username", currentUsername);
            prefs.putLong("leaderboard." + id + ".updated", System.currentTimeMillis());
            for (Course course : courses) {
                int count = completed.getOrDefault(course.id, Set.of()).size();
                prefs.putInt("leaderboard." + id + ".completed." + course.id, Math.max(0, Math.min(500, count)));
            }
        }
    }

    private void showLoginDialog() {
        String savedUsername = prefs.get("session.username", "");
        String savedName = prefs.get("session.name", "");
        if (!savedUsername.isBlank() && !savedName.isBlank()) {
            currentUsername = savedUsername;
            currentUserName = savedName;
            return;
        }

        JTextField nameField = new JTextField(22);
        JTextField usernameField = new JTextField(22);
        JPasswordField passwordField = new JPasswordField(22);
        JPanel fields = new JPanel(new GridBagLayout());
        fields.setBorder(new EmptyBorder(6, 6, 6, 6));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(0, 0, 12, 0);
        JLabel intro = new JLabel("<html><b>Desktopcraft profile</b><br><span style='color:#68736d'>Create account writes a safe identity file with no password.<br>Use a Desktopcraft-only password—never your email password.</span></html>");
        fields.add(intro, constraints);
        constraints.gridwidth = 1;
        constraints.gridy++;
        constraints.insets = new Insets(4, 0, 4, 10);
        fields.add(new JLabel("Display name"), constraints);
        constraints.gridx = 1;
        constraints.insets = new Insets(4, 0, 4, 0);
        fields.add(nameField, constraints);
        constraints.gridx = 0;
        constraints.gridy++;
        constraints.insets = new Insets(4, 0, 4, 10);
        fields.add(new JLabel("Desktopcraft username"), constraints);
        constraints.gridx = 1;
        constraints.insets = new Insets(4, 0, 4, 0);
        fields.add(usernameField, constraints);
        constraints.gridx = 0;
        constraints.gridy++;
        constraints.insets = new Insets(4, 0, 4, 10);
        fields.add(new JLabel("Desktopcraft password"), constraints);
        constraints.gridx = 1;
        constraints.insets = new Insets(4, 0, 4, 0);
        fields.add(passwordField, constraints);

        Object[] options = {"Sign in", "Create account + file", "Use account file", "Continue as guest"};
        while (true) {
            int choice = JOptionPane.showOptionDialog(
                frame,
                fields,
                "Welcome to Desktopcraft",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                new ImageIcon(buildAppIcon(64)),
                options,
                options[0]
            );
            if (choice == 3 || choice == JOptionPane.CLOSED_OPTION) {
                currentUserName = "Guest learner";
                currentUsername = "";
                return;
            }
            if (choice == 2) {
                loadAccountMemoryFile(nameField, usernameField, passwordField);
                continue;
            }

            String username = usernameField.getText().trim().toLowerCase();
            char[] passwordChars = passwordField.getPassword();
            String password = new String(passwordChars);
            java.util.Arrays.fill(passwordChars, '\0');
            if (!username.matches("^[a-z0-9_.-]{3,24}$")) {
                showLoginError("Use 3–24 letters, numbers, dots, dashes, or underscores for your username.");
                continue;
            }
            if (password.length() < 8) {
                showLoginError("Use at least eight characters for your Desktopcraft password.");
                continue;
            }

            String accountId = accountId(username);
            String hashKey = "account." + accountId + ".hash";
            Path createdAccountFile = null;
            if (choice == 1) {
                String name = nameField.getText().trim();
                if (name.length() < 2) {
                    showLoginError("Enter a display name with at least two characters.");
                    continue;
                }
                if (prefs.get(hashKey, null) != null) {
                    showLoginError("That Desktopcraft username is already taken.");
                    continue;
                }
                try {
                    createdAccountFile = createAccountMemoryFile(name, username);
                } catch (IOException exception) {
                    showLoginError("Could not create the account memory file: " + exception.getMessage());
                    continue;
                }
                prefs.put(hashKey, passwordHash(password));
                prefs.put("account." + accountId + ".name", name);
                prefs.put("account." + accountId + ".username", username);
                currentUserName = name;
                currentUsername = username;
            } else {
                String expected = prefs.get(hashKey, null);
                if (expected == null || !expected.equals(passwordHash(password))) {
                    showLoginError("Desktopcraft username or password is incorrect.");
                    continue;
                }
                currentUserName = prefs.get("account." + accountId + ".name", "Builder");
                currentUsername = username;
            }
            prefs.put("session.username", currentUsername);
            prefs.put("session.name", currentUserName);
            if (createdAccountFile != null) {
                JTextArea location = new JTextArea("Account created. Your password-free memory file is here:\n\n" + createdAccountFile.toAbsolutePath() + "\n\nUse that file later to refill your name and username; your Desktopcraft password is still required.");
                location.setEditable(false);
                location.setLineWrap(true);
                location.setWrapStyleWord(true);
                location.setBackground(UIManager.getColor("Panel.background"));
                location.setPreferredSize(new Dimension(480, 120));
                JOptionPane.showMessageDialog(frame, location, "Account memory file created", JOptionPane.INFORMATION_MESSAGE, new ImageIcon(buildAppIcon(32)));
            }
            return;
        }
    }

    private void loadAccountMemoryFile(JTextField nameField, JTextField usernameField, JPasswordField passwordField) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose a Desktopcraft account memory file");
        chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Desktopcraft account files (*.json)", "json"));
        if (chooser.showOpenDialog(frame) != JFileChooser.APPROVE_OPTION) return;
        try {
            Path file = chooser.getSelectedFile().toPath();
            if (Files.size(file) > 32000) throw new IOException("The selected file is too large.");
            String json = Files.readString(file, StandardCharsets.UTF_8);
            String format = accountMemoryValue(json, "format");
            String username = accountMemoryValue(json, "username").toLowerCase(Locale.ROOT);
            String name = accountMemoryValue(json, "name");
            if (!"desktopcraft-account-memory-v1".equals(format) || !username.matches("^[a-z0-9_.-]{3,24}$")) {
                throw new IOException("That is not a valid Desktopcraft account memory file.");
            }
            usernameField.setText(username);
            nameField.setText(name);
            passwordField.requestFocusInWindow();
            JOptionPane.showMessageDialog(frame, "Account file loaded for @" + username + ". Enter the Desktopcraft password and choose Sign in.", "Account file loaded", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException exception) {
            showLoginError("Could not load the account memory file: " + exception.getMessage());
        }
    }

    private static Path createAccountMemoryFile(String name, String username) throws IOException {
        Path root = Path.of(System.getProperty("user.home"), ".desktopcraft");
        Path primary = root.resolve("account-files");
        Files.createDirectories(primary);
        long primaryCount;
        try (var files = Files.list(primary)) {
            primaryCount = files.filter(path -> path.getFileName().toString().endsWith(".account.json")).limit(101).count();
        }
        Path folder = accountFileFolderForCount(root, primaryCount);
        Files.createDirectories(folder);
        String storageTier = primaryCount < 100 ? "desktop-primary" : "desktop-overflow";
        String json = "{\n" +
            "  \"format\": \"desktopcraft-account-memory-v1\",\n" +
            "  \"name\": \"" + jsonEscape(name) + "\",\n" +
            "  \"username\": \"" + jsonEscape(username) + "\",\n" +
            "  \"createdAt\": " + System.currentTimeMillis() + ",\n" +
            "  \"storageTier\": \"" + storageTier + "\",\n" +
            "  \"passwordIncluded\": false,\n" +
            "  \"note\": \"This file remembers your Desktopcraft identity. Your password remains a local hash in the app preferences.\"\n" +
            "}\n";
        Path target = folder.resolve(username + ".account.json");
        if (Files.exists(target)) target = folder.resolve(username + "-" + System.currentTimeMillis() + ".account.json");
        return Files.writeString(target, json, StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
    }

    private static Path accountFileFolderForCount(Path root, long primaryCount) {
        return root.resolve(primaryCount < 100 ? "account-files" : "account-files-overflow");
    }

    private static boolean verifyAccountFileSupport() {
        try {
            Path memoryTestRoot = Path.of("desktopcraft-memory-test");
            String sample = "{\"format\":\"desktopcraft-account-memory-v1\",\"name\":\"Ada Builder\",\"username\":\"ada_builder\"}";
            return accountFileFolderForCount(memoryTestRoot, 99).endsWith("account-files")
                && accountFileFolderForCount(memoryTestRoot, 100).endsWith("account-files-overflow")
                && "desktopcraft-account-memory-v1".equals(accountMemoryValue(sample, "format"))
                && "ada_builder".equals(accountMemoryValue(sample, "username"));
        } catch (IOException exception) {
            return false;
        }
    }

    private static String accountMemoryValue(String json, String key) throws IOException {
        Matcher matcher = Pattern.compile("\\\"" + Pattern.quote(key) + "\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"\\\\])*)\\\"").matcher(json);
        if (!matcher.find()) throw new IOException("The file is missing " + key + ".");
        return matcher.group(1)
            .replace("\\n", "\n")
            .replace("\\r", "\r")
            .replace("\\\"", "\"")
            .replace("\\\\", "\\");
    }

    private static String jsonEscape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", "\\r").replace("\n", "\\n");
    }

    private void showLoginError(String message) {
        JOptionPane.showMessageDialog(frame, message, "Could not sign in", JOptionPane.ERROR_MESSAGE, new ImageIcon(buildAppIcon(32)));
    }

    private static String accountId(String username) {
        return passwordHash("username:" + username).substring(0, 32);
    }

    private static String passwordHash(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(("desktopcraft-local-v2:" + value).getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is unavailable", exception);
        }
    }

    private static List<Image> buildAppIcons() {
        return List.of(buildAppIcon(16), buildAppIcon(32), buildAppIcon(64), buildAppIcon(128));
    }

    private static Image buildAppIcon(int size) {
        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = image.createGraphics();
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        float scale = size / 64f;
        graphics.scale(scale, scale);
        graphics.setColor(NAV);
        graphics.fillRoundRect(0, 0, 64, 64, 14, 14);
        graphics.setColor(PAPER);
        graphics.fillRoundRect(11, 12, 42, 31, 5, 5);
        graphics.setColor(LIME);
        graphics.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        graphics.drawRoundRect(11, 12, 42, 31, 5, 5);
        graphics.setColor(GREEN);
        graphics.setStroke(new BasicStroke(3.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        graphics.drawLine(24, 24, 18, 29);
        graphics.drawLine(18, 29, 24, 34);
        graphics.drawLine(40, 24, 46, 29);
        graphics.drawLine(46, 29, 40, 34);
        graphics.drawLine(35, 20, 29, 38);
        graphics.setColor(LIME);
        graphics.drawLine(32, 43, 32, 51);
        graphics.drawLine(23, 53, 41, 53);
        graphics.setColor(new Color(238, 148, 93));
        graphics.fillOval(44, 13, 8, 8);
        graphics.dispose();
        return image;
    }

    private void bindKeyboardShortcuts() {
        KeyStroke run = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx());
        frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(run, "run-code");
        frame.getRootPane().getActionMap().put("run-code", new AbstractAction() {
            public void actionPerformed(ActionEvent event) { runSimulation(); }
        });
        KeyStroke search = KeyStroke.getKeyStroke(KeyEvent.VK_F, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx());
        frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(search, "search-lessons");
        frame.getRootPane().getActionMap().put("search-lessons", new AbstractAction() {
            public void actionPerformed(ActionEvent event) { searchField.requestFocusInWindow(); }
        });
    }

    private static JButton primaryButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(GREEN);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(new CompoundBorder(new LineBorder(new Color(32, 91, 67)), new EmptyBorder(8, 13, 8, 13)));
        return button;
    }

    private static JButton secondaryButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(PAPER);
        button.setForeground(MUTED);
        button.setFocusPainted(false);
        button.setBorder(new CompoundBorder(new LineBorder(new Color(216, 217, 209)), new EmptyBorder(8, 13, 8, 13)));
        return button;
    }

    private static JButton toolbarButton(String text) {
        JButton button = new JButton(text);
        button.setForeground(new Color(190, 202, 194));
        button.setBackground(EDITOR_BAR);
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(4, 8, 4, 8));
        return button;
    }

    private static JButton darkButton(String text) {
        JButton button = new JButton(text);
        button.setForeground(Color.WHITE);
        button.setBackground(NAV_ACTIVE);
        button.setFocusPainted(false);
        button.setBorder(new CompoundBorder(new LineBorder(new Color(63, 87, 76)), new EmptyBorder(8, 10, 8, 10)));
        return button;
    }

    private static JLabel smallLabel(String text, Color color) {
        JLabel label = new JLabel(text);
        label.setForeground(color);
        label.setFont(new Font("SansSerif", Font.BOLD, 10));
        return label;
    }

    private static boolean balanced(String source, char open, char close) {
        int depth = 0;
        boolean quoted = false;
        boolean escaped = false;
        for (char value : source.toCharArray()) {
            if (escaped) {
                escaped = false;
                continue;
            }
            if (value == '\\') {
                escaped = true;
                continue;
            }
            if (value == '"') quoted = !quoted;
            if (quoted) continue;
            if (value == open) depth++;
            if (value == close && --depth < 0) return false;
        }
        return depth == 0;
    }

    private static String normalizeLessonAnswer(String value) {
        return value.replace("\r\n", "\n").trim();
    }

    private static String simpleLessonText(String value) {
        String result = String.valueOf(value == null ? "" : value);
        String[][] replacements = {
            {"Event Dispatch Thread", "Swing UI thread"}, {"operating-system", "system"}, {"top-level", "main"},
            {"non-editable", "read-only"}, {"configuration", "settings"}, {"Configuration", "Settings"},
            {"configures", "sets up"}, {"configure", "set up"}, {"Configure", "Set up"},
            {"initializes", "starts"}, {"initialize", "start"}, {"Initialize", "Start"},
            {"constructs", "creates"}, {"construct", "create"}, {"Construct", "Create"},
            {"invokes", "runs"}, {"invoked", "run"}, {"dispatches", "sends"}, {"dispatch", "send"},
            {"supplied", "given"}, {"reusable", "shared"}, {"constrained", "limited"},
            {"hierarchical", "tree-like"}, {"periodic", "repeated"}, {"privileged", "system-level"},
            {"asynchronous", "background"}, {"dynamically", "as it runs"}, {"immediately", "right away"},
            {"subsequent", "next"}, {"corresponding", "matching"}, {"appropriate", "right"},
            {"explicit", "clear"}, {"concise", "short"}, {"responsibility", "job"},
            {"composition", "putting parts together"}, {"architecture", "design"}, {"functionality", "features"},
            {"curriculum", "course"}, {"estimated", "planned"}, {"primary", "main"}, {"central", "main"},
            {"geometry", "size and position"}, {"interface state", "screen data"}, {"application state", "app data"},
            {"interfaces", "screens"}, {"interface", "screen"}, {"components", "controls"}, {"component", "control"},
            {"containers", "holders"}, {"container", "holder"}, {"reflect the result", "show the result"},
            {"represents", "shows"}, {"persist", "save"}, {"lifecycle", "start-to-finish steps"}
        };
        boolean startsUppercase = !result.isEmpty() && Character.isUpperCase(result.charAt(0));
        for (String[] replacement : replacements) {
            result = result.replaceAll("(?i)(?<![A-Za-z])" + Pattern.quote(replacement[0]) + "(?![A-Za-z])", Matcher.quoteReplacement(replacement[1]));
        }
        if (startsUppercase && !result.isEmpty()) result = Character.toUpperCase(result.charAt(0)) + result.substring(1);
        return result;
    }

    private static String html(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private class LessonRenderer extends JPanel implements ListCellRenderer<LessonRef> {
        private final JLabel number = new JLabel();
        private final JLabel title = new JLabel();
        private final JLabel subtitle = new JLabel();

        LessonRenderer() {
            setLayout(new BorderLayout(10, 0));
            setBorder(new EmptyBorder(5, 8, 5, 8));
            number.setHorizontalAlignment(SwingConstants.CENTER);
            number.setPreferredSize(new Dimension(40, 34));
            JPanel copy = new JPanel(new GridLayout(2, 1));
            copy.setOpaque(false);
            title.setFont(new Font("SansSerif", Font.BOLD, 11));
            subtitle.setFont(new Font("SansSerif", Font.PLAIN, 9));
            copy.add(title);
            copy.add(subtitle);
            add(number, BorderLayout.WEST);
            add(copy, BorderLayout.CENTER);
        }

        public Component getListCellRendererComponent(JList<? extends LessonRef> list, LessonRef value, int index, boolean selected, boolean focus) {
            boolean done = completed.getOrDefault(currentCourse.id, Set.of()).contains(value.index);
            setBackground(selected ? NAV_ACTIVE : NAV);
            number.setText(done ? "✓" : String.format("%03d", value.index + 1));
            number.setOpaque(true);
            number.setBackground(selected ? LIME : new Color(43, 59, 51));
            number.setForeground(selected ? NAV : new Color(201, 213, 205));
            title.setText(value.lesson.title);
            title.setForeground(selected ? Color.WHITE : new Color(199, 210, 203));
            subtitle.setText(value.lesson.api);
            subtitle.setForeground(new Color(126, 145, 134));
            return this;
        }
    }

    private static List<Course> loadCourses() {
        List<Course> result = new ArrayList<>();
        List<Lesson> swing = new ArrayList<>();
        swing.add(new Lesson("Swing foundations", "Give your app a window", "JFrame", "Create and reveal the top-level Swing window.", "Hello, Swing!", "My Swing App", javaCode("Give your app a window", "JFrame", "Hello, Swing!")));
        swing.add(new Lesson("Swing foundations", "Let layouts do the measuring", "GridLayout", "Arrange controls with flexible layout rules.", "Grid created", "Grid spacing improved", javaCode("Layout managers", "GridLayout", "Grid created")));
        swing.add(new Lesson("Swing foundations", "Make the interface respond", "ActionListener", "Connect user actions to application behavior.", "Action received", "Action listener connected", javaCode("Events", "ActionListener", "Action received")));
        swing.add(new Lesson("Swing foundations", "Turn input into an answer", "JTextField", "Read current input inside its event callback.", "Hello, learner", "Welcome, learner", javaCode("Inputs", "JTextField", "Hello, learner")));
        swing.add(new Lesson("Swing foundations", "Ship a tiny task list", "DefaultListModel", "Combine input, models, events, and a visible collection.", "Learn Swing", "Build my first app", javaCode("Task list", "DefaultListModel", "Learn Swing")));
        parseSwingResource("/lessons-extra.js", swing);
        result.add(new Course("java-swing", "Java Swing: Zero to Builder", "Java Swing", "Java", "Main.java", swing));

        parseDesktopCourse("/desktop-courses.js", "python-tkinter", "Python Tkinter Desktop Apps", "Tkinter", "Python", "app.py", result);
        parseDesktopCourse("/desktop-courses.js", "csharp-winforms", "C# Windows Forms Apps", "WinForms", "C#", "MainForm.cs", result);
        parseDesktopCourse("/desktop-courses.js", "cpp-qt", "C++ Qt Widgets Apps", "Qt Widgets", "C++", "main.cpp", result);
        parseDesktopCourse("/desktop-courses.js", "javascript-electron", "JavaScript Electron Desktop Apps", "Electron", "JavaScript", "renderer.js", result);
        expandCourses(result, 500);
        return result;
    }

    private static void expandCourses(List<Course> courses, int target) {
        for (Course course : courses) {
            if (course.lessons.size() > target) course.lessons.subList(target, course.lessons.size()).clear();
            while (course.lessons.size() < target) {
                course.lessons.add(generatedLesson(course, course.lessons.size() + 1));
            }
        }
    }

    private static Lesson generatedLesson(Course course, int lessonNumber) {
        List<String> modules = switch (course.language) {
            case "Java" -> List.of("Component mastery", "Layouts and composition", "Events and state", "Models and data", "Polish and accessibility", "Projects and architecture");
            case "Python" -> List.of("Widget mastery", "Geometry and composition", "Events and state", "Data-driven interfaces", "Polish and accessibility", "Projects and architecture");
            case "C#" -> List.of("Control mastery", "Layout and composition", "Events and state", "Data-bound interfaces", "Polish and accessibility", "Projects and architecture");
            case "C++" -> List.of("Widget mastery", "Layout and composition", "Signals and state", "Model/view interfaces", "Polish and accessibility", "Projects and architecture");
            default -> List.of("Renderer mastery", "Layout and composition", "Events and state", "Secure desktop data", "Polish and accessibility", "Projects and architecture");
        };
        List<String> apis = switch (course.language) {
            case "Java" -> List.of("JFrame", "JPanel", "JLabel", "JButton", "JTextField", "JTextArea", "JCheckBox", "JRadioButton", "JComboBox", "JList", "JTable", "JTree", "JTabbedPane", "JSplitPane", "JScrollPane", "BorderLayout", "GridBagLayout", "BoxLayout", "Action", "KeyStroke", "DocumentListener", "SwingWorker", "Timer", "TableModel", "ListModel");
            case "Python" -> List.of("Tk", "ttk.Frame", "ttk.Label", "ttk.Button", "ttk.Entry", "Text", "ttk.Checkbutton", "ttk.Radiobutton", "ttk.Combobox", "Listbox", "ttk.Treeview", "ttk.Notebook", "ttk.Panedwindow", "Canvas", "pack", "grid", "place", "StringVar", "bind", "after", "messagebox", "filedialog", "ttk.Progressbar", "Menu", "Toplevel");
            case "C#" -> List.of("Form", "Panel", "Label", "Button", "TextBox", "RichTextBox", "CheckBox", "RadioButton", "ComboBox", "ListBox", "DataGridView", "TreeView", "TabControl", "SplitContainer", "FlowLayoutPanel", "TableLayoutPanel", "Click", "KeyDown", "ErrorProvider", "BindingSource", "Timer", "async / await", "MenuStrip", "ProgressBar", "UserControl");
            case "C++" -> List.of("QApplication", "QWidget", "QLabel", "QPushButton", "QLineEdit", "QTextEdit", "QCheckBox", "QRadioButton", "QComboBox", "QListWidget", "QTableView", "QTreeView", "QTabWidget", "QSplitter", "QVBoxLayout", "QGridLayout", "signals and slots", "QAction", "QValidator", "QStringListModel", "QTimer", "QThread", "QMenuBar", "QProgressBar", "QDialog");
            default -> List.of("BrowserWindow", "HTMLElement", "HTMLButtonElement", "HTMLInputElement", "HTMLTextAreaElement", "checkbox input", "radio input", "select element", "dialog element", "CSS Grid", "Flexbox", "addEventListener", "CustomEvent", "FormData", "contextBridge", "ipcRenderer.invoke", "ipcMain.handle", "Menu", "Tray", "Notification", "globalShortcut", "fs/promises", "localStorage", "ARIA", "Electron Forge");
        };
        List<String> projects = List.of("profile editor", "task board", "notes desk", "budget panel", "timer dashboard", "contact book", "inventory tool", "study planner", "music queue", "weather console");
        List<String> skills = List.of("Create", "Configure", "Connect", "Validate", "Update", "Organize", "Test", "Refactor", "Reuse", "Ship");
        int offset = lessonNumber - 1;
        int moduleIndex = Math.floorDiv(offset, (int) Math.ceil(500d / modules.size())) % modules.size();
        String module = modules.get(moduleIndex);
        String api = apis.get(offset % apis.size());
        String project = projects.get((offset * 3 + moduleIndex) % projects.size());
        String skill = skills.get((offset + moduleIndex) % skills.size());
        String title = skill + " " + api + " in a " + project + " — Lab " + lessonNumber;
        String starter = "Lab " + lessonNumber + " ready";
        String goal = api + " lab " + lessonNumber + " complete";
        String description = "Practice how " + api + " supports a " + project + ", connect it to one clear piece of interface state, and verify the result in the desktop simulator.";
        String code = "Java".equals(course.language)
            ? javaCode(title, api, starter)
            : languageCode(course.language, title, api, starter);
        return new Lesson(module, title, api, description, starter, goal, code);
    }

    private static void parseSwingResource(String resource, List<Lesson> target) {
        String source = readResource(resource);
        String module = "Swing practice";
        Pattern modulePattern = Pattern.compile("^\\s*name:\\s*\"([^\"]+)\"", Pattern.MULTILINE);
        Pattern lessonPattern = Pattern.compile("^\\s*\\[\"([^\"]+)\",\\s*\"([^\"]+)\",\\s*\"([^\"]+)\",\\s*\"([^\"]+)\",\\s*\"([^\"]+)\",\\s*\"([^\"]+)\"\\],?", Pattern.MULTILINE);
        List<PositionedModule> modules = new ArrayList<>();
        Matcher moduleMatcher = modulePattern.matcher(source);
        while (moduleMatcher.find()) modules.add(new PositionedModule(moduleMatcher.start(), moduleMatcher.group(1)));
        Matcher matcher = lessonPattern.matcher(source);
        while (matcher.find()) {
            for (PositionedModule positioned : modules) if (positioned.position <= matcher.start()) module = positioned.name;
            String title = matcher.group(1), api = matcher.group(3), detail = matcher.group(4), starter = matcher.group(5), goal = matcher.group(6);
            target.add(new Lesson(module, title, api, detail, starter, goal, javaCode(title, api, starter)));
        }
    }

    private static void parseDesktopCourse(String resource, String id, String title, String shortTitle, String language, String fileName, List<Course> target) {
        String source = readResource(resource);
        int start = source.indexOf("id: \"" + id + "\"");
        if (start < 0) return;
        int next = source.indexOf("id: \"", start + 8);
        int definitionsEnd = source.indexOf("const escapeText", start);
        int end = next > 0 ? next : definitionsEnd > 0 ? definitionsEnd : source.length();
        String block = source.substring(start, end);
        Pattern modulePattern = Pattern.compile("^\\s*\\[\"([^\"]+)\",\\s*\\[$", Pattern.MULTILINE);
        Pattern lessonPattern = Pattern.compile("^\\s*\\[\"([^\"]+)\",\\s*\"([^\"]+)\",\\s*\"([^\"]+)\",\\s*\"([^\"]+)\",\\s*\"([^\"]+)\"\\],?", Pattern.MULTILINE);
        List<PositionedModule> modules = new ArrayList<>();
        Matcher moduleMatcher = modulePattern.matcher(block);
        while (moduleMatcher.find()) modules.add(new PositionedModule(moduleMatcher.start(), moduleMatcher.group(1)));
        List<Lesson> lessons = new ArrayList<>();
        Matcher matcher = lessonPattern.matcher(block);
        while (matcher.find()) {
            String module = "Desktop foundations";
            for (PositionedModule positioned : modules) if (positioned.position <= matcher.start()) module = positioned.name;
            String lessonTitle = matcher.group(1), api = matcher.group(2), detail = matcher.group(3), starter = matcher.group(4), goal = matcher.group(5);
            lessons.add(new Lesson(module, lessonTitle, api, detail, starter, goal, languageCode(language, lessonTitle, api, starter)));
        }
        target.add(new Course(id, title, shortTitle, language, fileName, lessons));
    }

    private static String readResource(String path) {
        try (InputStream stream = DesktopcraftApp.class.getResourceAsStream(path)) {
            if (stream == null) return "";
            return new String(stream.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException exception) {
            return "";
        }
    }

    private static String languageCode(String language, String title, String api, String starter) {
        return switch (language) {
            case "Python" -> "import tkinter as tk\nfrom tkinter import ttk\n\nroot = tk.Tk()\nroot.title(\"" + title + "\")\npanel = ttk.Frame(root, padding=18)\npanel.pack(fill=\"both\", expand=True)\nstatus = ttk.Label(panel, text=\"Ready\")\nentry = ttk.Entry(panel)\nentry.insert(0, \"Desktop app\")\n\ndef run_demo():\n    status.config(text=\"" + starter + "\")\n\naction = ttk.Button(panel, text=\"Try " + api + "\", command=run_demo)\nentry.pack(pady=6)\naction.pack(pady=6)\nstatus.pack(pady=6)\nroot.mainloop()";
            case "C#" -> "using System;\nusing System.Windows.Forms;\n\npublic class MainForm : Form\n{\n    public MainForm()\n    {\n        Text = \"" + title + "\";\n        var panel = new FlowLayoutPanel { Dock = DockStyle.Fill };\n        var input = new TextBox { Text = \"Desktop app\" };\n        var action = new Button { Text = \"Try " + api + "\" };\n        var status = new Label { Text = \"Ready\" };\n        action.Click += (sender, args) => status.Text = \"" + starter + "\";\n        panel.Controls.Add(input);\n        panel.Controls.Add(action);\n        panel.Controls.Add(status);\n        Controls.Add(panel);\n    }\n    [STAThread] public static void Main() => Application.Run(new MainForm());\n}";
            case "C++" -> "#include <QApplication>\n#include <QLabel>\n#include <QLineEdit>\n#include <QPushButton>\n#include <QVBoxLayout>\n#include <QWidget>\n\nint main(int argc, char *argv[]) {\n    QApplication app(argc, argv);\n    QWidget window;\n    window.setWindowTitle(\"" + title + "\");\n    auto *layout = new QVBoxLayout(&window);\n    auto *input = new QLineEdit(\"Desktop app\");\n    auto *action = new QPushButton(\"Try " + api + "\");\n    auto *status = new QLabel(\"Ready\");\n    layout->addWidget(input); layout->addWidget(action); layout->addWidget(status);\n    QObject::connect(action, &QPushButton::clicked, [=]() { status->setText(\"" + starter + "\"); });\n    window.show();\n    return app.exec();\n}";
            case "JavaScript" -> "document.title = \"" + title + "\";\nconst app = document.querySelector(\"#app\");\napp.innerHTML = `\n  <input id=\"input\" value=\"Desktop app\" />\n  <button id=\"action\">Try " + api + "</button>\n  <p id=\"status\">Ready</p>\n`;\nconst status = document.querySelector(\"#status\");\ndocument.querySelector(\"#action\").addEventListener(\"click\", () => {\n  status.textContent = \"" + starter + "\";\n});";
            default -> "";
        };
    }

    private static String javaCode(String title, String api, String starter) {
        return "import javax.swing.*;\nimport java.awt.*;\n\npublic class Main {\n    public static void main(String[] args) {\n        SwingUtilities.invokeLater(() -> {\n            JFrame frame = new JFrame(\"" + title + "\");\n            JTextField input = new JTextField(\"Desktop app\", 14);\n            JButton action = new JButton(\"Try " + api + "\");\n            JLabel status = new JLabel(\"Ready\");\n            action.addActionListener(e -> status.setText(\"" + starter + "\"));\n            JPanel panel = new JPanel(new FlowLayout());\n            panel.add(input); panel.add(action); panel.add(status);\n            frame.add(panel);\n            frame.setSize(430, 220);\n            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);\n            frame.setVisible(true);\n        });\n    }\n}";
    }

    private record Course(String id, String title, String shortTitle, String language, String fileName, List<Lesson> lessons) {
        public String toString() { return language + " · " + shortTitle; }
    }
    private record AppBlueprint(String toolkit, String appName, String windowTitle, String message, String buttonLabel, String actionMessage, int width, int height) {}
    private record Lesson(String module, String title, String api, String description, String starter, String goal, String code) {}
    private record QuizQuestion(String question, List<String> options, int answer, String explanation) {}
    private record LessonRef(int index, Lesson lesson) { public String toString() { return lesson.title; } }
    private record Builder(String name, String username, String focus, int xp) {}
    private record PositionedModule(int position, String name) {}
}
