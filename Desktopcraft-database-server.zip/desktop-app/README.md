# Desktopcraft Swing edition

The downloadable desktop tutor is a self-contained Java Swing application with the same five courses and 2,500-lesson catalog as the website: 500 lessons per language. Every lesson includes editable code, a simulated desktop preview, an automatically checked challenge, and a native 20-question quiz with one-at-a-time checking, Next controls, correct-answer reveals, and explanations. It also includes sign-in with a Desktopcraft username and a separate Desktopcraft-only password—never an email password—plus persistent session identity, course progress, XP, a leaderboard, and a custom Desktopcraft window icon. Creating an account writes a password-free JSON memory file under `~/.desktopcraft/account-files`; after 100 primary files, later files go to `~/.desktopcraft/account-files-overflow`.

The lesson studio lets the learner provide a lesson name, starter code, answer, and expected output. Custom lessons persist locally. Its profanity policy is shown before submission: a violation erases the draft and all custom lessons, then permanently disables creation for the local app profile.

App Maker provides a live blueprint, preview, generated source, clipboard copy, and source-file save flow for Java Swing, Python Tkinter, C# WinForms, C++ Qt Widgets, and JavaScript Electron.

The leaderboard ranks only actual Desktopcraft accounts stored by the desktop app. Every completed lesson adds 100 XP to that account's saved total; sample names and fabricated scores are not included.

## Run the packaged app

Java 17 or newer is required.

```bash
java -jar Desktopcraft.jar
```

## Build from source

From the repository root:

```bash
mkdir -p desktop-app/build downloads
javac --release 17 -d desktop-app/build desktop-app/src/DesktopcraftApp.java
jar --create --file downloads/Desktopcraft.jar --main-class DesktopcraftApp -C desktop-app/build . lessons-extra.js desktop-courses.js
```

The two JavaScript curriculum files are packaged as read-only JAR resources. The Swing application parses their lesson metadata at startup, generates language-appropriate examples, and stores completion locally through Java Preferences.
