const form = document.querySelector("#authForm");
const signInTab = document.querySelector("#signInTab");
const createTab = document.querySelector("#createTab");
const nameField = document.querySelector("#nameField");
const displayName = document.querySelector("#displayName");
const username = document.querySelector("#username");
const password = document.querySelector("#password");
const submitButton = document.querySelector("#authSubmit");
const errorBox = document.querySelector("#authError");
const formKicker = document.querySelector("#formKicker");
const formTitle = document.querySelector("#formTitle");
const formDescription = document.querySelector("#formDescription");
const accountFileButton = document.querySelector("#accountFileButton");
const accountFileInput = document.querySelector("#accountFileInput");

let mode = "sign-in";

function setMode(nextMode) {
  mode = nextMode;
  const creating = mode === "create";
  signInTab.classList.toggle("active", !creating);
  createTab.classList.toggle("active", creating);
  signInTab.setAttribute("aria-selected", String(!creating));
  createTab.setAttribute("aria-selected", String(creating));
  nameField.hidden = !creating;
  displayName.required = creating;
  password.autocomplete = creating ? "new-password" : "current-password";
  formKicker.textContent = creating ? "START YOUR PROFILE" : "WELCOME BACK";
  formTitle.textContent = creating ? "Join the builder league" : "Continue building";
  formDescription.textContent = creating
    ? "Create your Desktopcraft profile and download its account memory file."
    : "Sign in to your Desktopcraft profile.";
  submitButton.textContent = creating ? "Create account + memory file" : "Sign in";
  errorBox.hidden = true;
}

signInTab.addEventListener("click", () => setMode("sign-in"));
createTab.addEventListener("click", () => setMode("create"));

document.querySelector("#togglePassword").addEventListener("click", (event) => {
  const willShow = password.type === "password";
  password.type = willShow ? "text" : "password";
  event.currentTarget.textContent = willShow ? "Hide" : "Show";
  event.currentTarget.setAttribute("aria-label", willShow ? "Hide password" : "Show password");
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  errorBox.hidden = true;
  submitButton.disabled = true;
  submitButton.textContent = mode === "create" ? "Creating…" : "Signing in…";
  try {
    if (mode === "create") {
      const session = await window.DesktopcraftAuth.signUp({ name: displayName.value, username: username.value, password: password.value });
      window.DesktopcraftAuth.downloadAccountFile(session);
    } else {
      await window.DesktopcraftAuth.signIn({ username: username.value, password: password.value });
    }
    const next = new URLSearchParams(window.location.search).get("next");
    window.location.href = next && !next.includes(":") ? next : "index.html";
  } catch (error) {
    errorBox.textContent = error.message;
    errorBox.hidden = false;
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = mode === "create" ? "Create account + memory file" : "Sign in";
  }
});

accountFileButton.addEventListener("click", () => accountFileInput.click());
accountFileInput.addEventListener("change", async () => {
  errorBox.hidden = true;
  try {
    const profile = await window.DesktopcraftAuth.readAccountFile(accountFileInput.files?.[0]);
    setMode("sign-in");
    username.value = profile.username;
    displayName.value = profile.name;
    formDescription.textContent = `Account file loaded for ${profile.name || `@${profile.username}`}. Enter the Desktopcraft password to sign in.`;
    password.focus();
  } catch (error) {
    errorBox.textContent = error.message;
    errorBox.hidden = false;
  } finally {
    accountFileInput.value = "";
  }
});

const existingUser = window.DesktopcraftAuth.currentUser();
if (existingUser) {
  username.value = existingUser.username;
  formDescription.textContent = `Signed in as ${existingUser.name} (@${existingUser.username}). Sign in again or return to the course.`;
}
