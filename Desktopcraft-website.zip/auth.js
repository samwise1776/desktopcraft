(function () {
  const accountsKey = "desktopcraft-accounts-v2";
  const sessionKey = "desktopcraft-session-v2";
  const overflowFallbackKey = "desktopcraft-accounts-overflow-v2";
  const overflowDatabaseName = "desktopcraft-account-overflow-v1";
  const leaderboardKey = "desktopcraft-real-leaderboard-v1";
  const primaryAccountLimit = 100;

  const normalizeUsername = (username) => String(username || "").trim().toLowerCase();

  async function databaseRequest(path, options = {}) {
    const controller = window.AbortController ? new AbortController() : null;
    const timeout = controller ? window.setTimeout(() => controller.abort(), 2500) : null;
    const { headers = {}, ...requestOptions } = options;
    try {
      const response = await window.fetch(path, {
        credentials: "same-origin",
        headers: { "Content-Type": "application/json", ...headers },
        ...requestOptions,
        ...(controller ? { signal: controller.signal } : {})
      });
      const contentType = response.headers.get("content-type") || "";
      if (!contentType.includes("application/json")) return { available: false };
      const data = await response.json();
      if (!response.ok) {
        const error = new Error(data.error || "Desktopcraft could not complete that database request.");
        error.databaseResponse = true;
        error.status = response.status;
        throw error;
      }
      return { available: true, data };
    } catch (error) {
      if (error.databaseResponse) throw error;
      return { available: false };
    } finally {
      if (timeout) window.clearTimeout(timeout);
    }
  }

  function readJson(key, fallback) {
    try {
      return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));
    } catch {
      return fallback;
    }
  }

  function writeJson(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function openOverflowDatabase() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        reject(new Error("IndexedDB is unavailable"));
        return;
      }
      const request = window.indexedDB.open(overflowDatabaseName, 1);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains("accounts")) request.result.createObjectStore("accounts", { keyPath: "username" });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("Could not open overflow storage"));
    });
  }

  async function readOverflowAccounts() {
    try {
      const database = await openOverflowDatabase();
      const accounts = await new Promise((resolve, reject) => {
        const request = database.transaction("accounts", "readonly").objectStore("accounts").getAll();
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error || new Error("Could not read overflow accounts"));
      });
      database.close();
      const fallback = readJson(overflowFallbackKey, []);
      return [...accounts, ...fallback.filter((account) => !accounts.some((stored) => stored.username === account.username))];
    } catch {
      return readJson(overflowFallbackKey, []);
    }
  }

  async function writeOverflowAccount(account) {
    try {
      const database = await openOverflowDatabase();
      await new Promise((resolve, reject) => {
        const request = database.transaction("accounts", "readwrite").objectStore("accounts").put(account);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error || new Error("Could not write overflow account"));
      });
      database.close();
    } catch {
      const overflow = readJson(overflowFallbackKey, []);
      const existingIndex = overflow.findIndex((stored) => stored.username === account.username);
      if (existingIndex >= 0) overflow[existingIndex] = account;
      else overflow.push(account);
      writeJson(overflowFallbackKey, overflow);
    }
  }

  async function readAccountTiers() {
    let primary = readJson(accountsKey, []);
    if (primary.length > primaryAccountLimit) {
      const spillover = primary.slice(primaryAccountLimit);
      primary = primary.slice(0, primaryAccountLimit);
      writeJson(accountsKey, primary);
      for (const account of spillover) await writeOverflowAccount({ ...account, storageTier: "browser-overflow" });
    }
    return { primary, overflow: await readOverflowAccounts() };
  }

  async function storeLocalAccount(account) {
    const { primary, overflow } = await readAccountTiers();
    const primaryIndex = primary.findIndex((stored) => stored.username === account.username);
    if (primaryIndex >= 0) {
      primary[primaryIndex] = account;
      writeJson(accountsKey, primary);
      return;
    }
    if (overflow.some((stored) => stored.username === account.username)) {
      await writeOverflowAccount(account);
      return;
    }
    if (primary.length < primaryAccountLimit) {
      primary.push(account);
      writeJson(accountsKey, primary);
    } else {
      await writeOverflowAccount(account);
    }
  }

  async function hashPassword(password) {
    if (window.crypto?.subtle && window.TextEncoder) {
      const bytes = new TextEncoder().encode(`desktopcraft-local-v2:${password}`);
      const digest = await crypto.subtle.digest("SHA-256", bytes);
      return [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, "0")).join("");
    }

    let hash = 2166136261;
    for (const character of `desktopcraft-local-v2:${password}`) {
      hash ^= character.charCodeAt(0);
      hash = Math.imul(hash, 16777619);
    }
    return `fallback-${(hash >>> 0).toString(16)}`;
  }

  function currentUser() {
    const session = readJson(sessionKey, null);
    return session?.username && session?.name ? session : null;
  }

  function initials(name) {
    const parts = String(name || "Guest").trim().split(/\s+/).filter(Boolean);
    return parts.slice(0, 2).map((part) => part[0].toUpperCase()).join("") || "GU";
  }

  function safeCourseStats(stats) {
    const result = {};
    Object.entries(stats && typeof stats === "object" ? stats : {}).forEach(([courseId, course]) => {
      const total = Math.max(0, Math.min(500, Number(course?.total) || 500));
      const completed = Math.max(0, Math.min(total, Number(course?.completed) || 0));
      result[courseId] = { completed, total, updatedAt: Number(course?.updatedAt) || Date.now() };
    });
    return result;
  }

  function rememberLeaderboardAccount(account, stats) {
    if (!account?.username || !account?.name) return;
    const records = readJson(leaderboardKey, []);
    const index = records.findIndex((record) => record.username === account.username);
    const previous = index >= 0 ? records[index] : {};
    const record = {
      name: account.name,
      username: account.username,
      createdAt: Number(account.createdAt) || Number(previous.createdAt) || Date.now(),
      updatedAt: Date.now(),
      courses: stats ? safeCourseStats(stats) : safeCourseStats(previous.courses)
    };
    if (index >= 0) records[index] = record;
    else records.push(record);
    writeJson(leaderboardKey, records);
  }

  function recordProgress(stats, progressSnapshot) {
    const user = currentUser();
    if (!user) return false;
    try {
      rememberLeaderboardAccount(user, stats);
      if (progressSnapshot?.courseId && Array.isArray(progressSnapshot.completed)) {
        void databaseRequest("/api/progress", {
          method: "PUT",
          body: JSON.stringify(progressSnapshot)
        }).catch(() => {});
      }
      return true;
    } catch {
      return false;
    }
  }

  function saveQuizAttempt(attempt) {
    if (!currentUser()) return false;
    void databaseRequest("/api/quiz-attempts", {
      method: "POST",
      body: JSON.stringify(attempt)
    }).catch(() => {});
    return true;
  }

  async function loadDatabaseProgress() {
    try {
      const response = await databaseRequest("/api/progress");
      return response.available ? response.data.courses || [] : null;
    } catch {
      return null;
    }
  }

  async function databaseLeaderboard() {
    try {
      const response = await databaseRequest("/api/leaderboard");
      return response.available ? response.data.entries || [] : null;
    } catch {
      return null;
    }
  }

  async function restoreDatabaseSession() {
    try {
      const response = await databaseRequest("/api/auth/session");
      const user = response.available ? response.data.user : null;
      if (!user) return null;
      const session = { ...user, signedInAt: Date.now() };
      writeJson(sessionKey, session);
      rememberLeaderboardAccount(session);
      return session;
    } catch {
      return null;
    }
  }

  async function leaderboardEntries() {
    const { primary, overflow } = await readAccountTiers();
    const current = currentUser();
    const accounts = [...primary, ...overflow];
    if (current && !accounts.some((account) => account.username === current.username)) accounts.push(current);
    const records = readJson(leaderboardKey, []);
    return accounts
      .filter((account, index, all) => account.username && all.findIndex((candidate) => candidate.username === account.username) === index)
      .map((account) => {
        const record = records.find((candidate) => candidate.username === account.username);
        return {
          name: account.name,
          username: account.username,
          createdAt: Number(account.createdAt) || Date.now(),
          updatedAt: Number(record?.updatedAt) || 0,
          courses: safeCourseStats(record?.courses)
        };
      });
  }

  async function signUp({ name, username, password }) {
    const cleanName = String(name || "").trim();
    const cleanUsername = normalizeUsername(username);
    if (cleanName.length < 2) throw new Error("Enter a name with at least two characters.");
    if (!/^[a-z0-9_.-]{3,24}$/.test(cleanUsername)) {
      throw new Error("Use 3–24 letters, numbers, dots, dashes, or underscores for your username.");
    }
    if (String(password).length < 8) throw new Error("Use at least eight characters for your Desktopcraft password.");

    const { primary, overflow } = await readAccountTiers();
    if ([...primary, ...overflow].some((account) => account.username === cleanUsername)) throw new Error("That Desktopcraft username is already taken.");
    const database = await databaseRequest("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ name: cleanName, username: cleanUsername, password })
    });
    const databaseUser = database.available ? database.data.user : null;
    const storageTier = databaseUser?.storageTier || (primary.length < primaryAccountLimit ? "browser-primary" : "browser-overflow");
    const account = {
      name: databaseUser?.name || cleanName,
      username: databaseUser?.username || cleanUsername,
      passwordHash: await hashPassword(password),
      createdAt: Number(databaseUser?.createdAt) || Date.now(),
      storageTier
    };
    await storeLocalAccount(account);
    const session = { name: account.name, username: account.username, createdAt: account.createdAt, storageTier, signedInAt: Date.now() };
    writeJson(sessionKey, session);
    rememberLeaderboardAccount(session, {});
    return session;
  }

  async function signIn({ username, password }) {
    const cleanUsername = normalizeUsername(username);
    const { primary, overflow } = await readAccountTiers();
    const account = [...primary, ...overflow].find((candidate) => candidate.username === cleanUsername);
    const passwordHash = await hashPassword(password);
    let database;
    try {
      database = await databaseRequest("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ username: cleanUsername, password })
      });
    } catch (error) {
      if (error.status !== 401 || !account || account.passwordHash !== passwordHash) throw error;
      try {
        database = await databaseRequest("/api/auth/register", {
          method: "POST",
          body: JSON.stringify({ name: account.name, username: cleanUsername, password })
        });
      } catch (migrationError) {
        if (migrationError.status === 409) {
          throw new Error("That username already belongs to a database account. Use its Desktopcraft password.");
        }
        throw migrationError;
      }
    }

    if (database?.available) {
      const user = database.data.user;
      const databaseAccount = {
        name: user.name,
        username: user.username,
        passwordHash,
        createdAt: Number(user.createdAt) || Date.now(),
        storageTier: "database"
      };
      await storeLocalAccount(databaseAccount);
      const session = { name: databaseAccount.name, username: databaseAccount.username, createdAt: databaseAccount.createdAt, storageTier: "database", signedInAt: Date.now() };
      writeJson(sessionKey, session);
      rememberLeaderboardAccount(session);
      return session;
    }

    if (!account || account.passwordHash !== passwordHash) {
      throw new Error("Desktopcraft username or password is incorrect.");
    }
    const session = { name: account.name, username: account.username, createdAt: account.createdAt, storageTier: account.storageTier || "browser-primary", signedInAt: Date.now() };
    writeJson(sessionKey, session);
    rememberLeaderboardAccount(session);
    return session;
  }

  function signOut() {
    void databaseRequest("/api/auth/logout", { method: "POST", body: "{}" }).catch(() => {});
    localStorage.removeItem(sessionKey);
    localStorage.removeItem("desktopcraft-session-v1");
  }

  function downloadAccountFile(account) {
    const profile = {
      format: "desktopcraft-account-memory-v1",
      name: account.name,
      username: account.username,
      createdAt: account.createdAt || Date.now(),
      storageTier: account.storageTier || "browser-primary",
      passwordIncluded: false,
      note: "This file remembers your Desktopcraft identity. It never includes your Desktopcraft password."
    };
    const blob = new Blob([JSON.stringify(profile, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `desktopcraft-${account.username}.account.json`;
    link.hidden = true;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  async function readAccountFile(file) {
    if (!file || file.size > 32000) throw new Error("Choose a valid Desktopcraft account memory file.");
    let profile;
    try {
      profile = JSON.parse(await file.text());
    } catch {
      throw new Error("That account memory file could not be read.");
    }
    const fileUsername = normalizeUsername(profile?.username);
    if (profile?.format !== "desktopcraft-account-memory-v1" || !/^[a-z0-9_.-]{3,24}$/.test(fileUsername)) {
      throw new Error("That is not a valid Desktopcraft account memory file.");
    }
    return { name: String(profile.name || "").trim(), username: fileUsername };
  }

  window.DesktopcraftAuth = {
    currentUser,
    initials,
    signUp,
    signIn,
    signOut,
    downloadAccountFile,
    readAccountFile,
    recordProgress,
    leaderboardEntries,
    saveQuizAttempt,
    loadDatabaseProgress,
    databaseLeaderboard,
    restoreDatabaseSession
  };
})();
